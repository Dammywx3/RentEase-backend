        CREATE OR REPLACE FUNCTION public.ensure_payment_splits(p_payment_id uuid)
         RETURNS void
         LANGUAGE plpgsql
1       AS $function$
2       DECLARE
3         pmt record;
4         v_currency text;
5       
6         v_payee_user_id uuid;
7         v_fee numeric(15,2);
8         v_net numeric(15,2);
9       BEGIN
10        SELECT p.*
11        INTO pmt
12        FROM public.payments p
13        WHERE p.id = p_payment_id
14          AND p.deleted_at IS NULL
15        LIMIT 1;
16      
17        IF NOT FOUND THEN
18          RAISE EXCEPTION 'Payment not found: %', p_payment_id;
19        END IF;
20      
21        v_currency := COALESCE(pmt.currency::text, 'USD');
22      
23        -- if splits already exist, do nothing
24        IF EXISTS (SELECT 1 FROM public.payment_splits ps WHERE ps.payment_id = p_payment_id) THEN
25          RETURN;
26        END IF;
27      
28        -- Resolve payee user
29        IF pmt.reference_type = 'purchase' AND pmt.reference_id IS NOT NULL THEN
30          SELECT pp.seller_id
31            INTO v_payee_user_id
32          FROM public.property_purchases pp
33          WHERE pp.id = pmt.reference_id
34            AND pp.deleted_at IS NULL
35          LIMIT 1;
36      
37        ELSIF pmt.reference_type = 'rent_invoice' AND pmt.reference_id IS NOT NULL THEN
38          SELECT pr.owner_id
39            INTO v_payee_user_id
40          FROM public.rent_invoices ri
41          JOIN public.properties pr ON pr.id = ri.property_id
42          WHERE ri.id = pmt.reference_id
43            AND ri.deleted_at IS NULL
44          LIMIT 1;
45      
46        ELSE
47          SELECT pr.owner_id
48            INTO v_payee_user_id
49          FROM public.properties pr
50          WHERE pr.id = pmt.property_id
51            AND pr.deleted_at IS NULL
52          LIMIT 1;
53        END IF;
54      
55        IF v_payee_user_id IS NULL THEN
56          RAISE EXCEPTION 'Cannot resolve payee_user_id for payment % (ref_type=% ref_id=%)',
57            p_payment_id, pmt.reference_type, pmt.reference_id;
58        END IF;
59      
60        -- ✅ Fee/net must come from app (fees.config.ts) via payments columns
61        v_fee := COALESCE(pmt.platform_fee_amount, 0)::numeric(15,2);
62        v_net := COALESCE(pmt.payee_amount, (pmt.amount - v_fee))::numeric(15,2);
63      
64        IF v_fee < 0 OR v_net < 0 THEN
65          RAISE EXCEPTION 'Invalid fee/net: platform_fee_amount=% payee_amount=% for payment=%',
66            pmt.platform_fee_amount, pmt.payee_amount, p_payment_id;
67        END IF;
68      
69        INSERT INTO public.payment_splits(
70          payment_id, split_type, beneficiary_kind, beneficiary_user_id, amount, currency
71        )
72        VALUES
73          (p_payment_id, 'platform_fee'::public.split_type, 'platform'::public.beneficiary_kind, NULL, v_fee, v_currency),
74          (p_payment_id, 'payee'::public.split_type, 'user'::public.beneficiary_kind, v_payee_user_id, v_net, v_currency);
75      END;
76      $function$
