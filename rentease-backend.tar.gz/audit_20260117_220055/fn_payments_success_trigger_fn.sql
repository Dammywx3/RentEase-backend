        CREATE OR REPLACE FUNCTION public.payments_success_trigger_fn()
         RETURNS trigger
         LANGUAGE plpgsql
1       AS $function$
2       BEGIN
3         IF NEW.status = 'successful' AND OLD.status IS DISTINCT FROM NEW.status THEN
4           PERFORM wallet_credit_from_splits(NEW.id);
5         END IF;
6         RETURN NEW;
7       END;
8       $function$
