// src/routes/tenancies.ts
import type { FastifyInstance } from "fastify";

import { withRlsTransaction } from "../db.js";
import { createTenancyBodySchema, listTenanciesQuerySchema } from "../schemas/tenancies.schema.js";
import { createTenancy, getTenancies } from "../services/tenancies.service.js";

function getRlsCtx(req: any): { userId: string; organizationId: string } {
  const rls = req?.rls;
  if (rls?.userId && rls?.organizationId) {
    return { userId: String(rls.userId), organizationId: String(rls.organizationId) };
  }

  const user = req?.user;

  const userId =
    user?.id ??
    user?.userId ??
    user?.sub ??
    req?.auth?.userId ??
    req?.auth?.sub;

  const hdr =
    req?.headers?.["x-organization-id"] ??
    req?.headers?.["x-org-id"] ??
    req?.headers?.["x-organizationid"];

  const userOrg =
    user?.organization_id ??
    user?.organizationId ??
    user?.org_id ??
    user?.orgId;

  const organizationId = hdr ?? userOrg;

  if (!userId || !organizationId) {
    throw new Error(
      `Missing RLS ctx. userId=${String(userId ?? "")} organizationId=${String(organizationId ?? "")}. ` +
        `Pass header x-organization-id OR ensure auth sets req.rls.`
    );
  }

  return { userId: String(userId), organizationId: String(organizationId) };
}

export async function tenancyRoutes(app: FastifyInstance) {
  app.get("/v1/tenancies", { preHandler: [app.authenticate] }, async (req) => {
    const q = listTenanciesQuerySchema.parse((req as any).query ?? {});
    const ctx = getRlsCtx(req);

    const data = await withRlsTransaction(ctx, (client) =>
      getTenancies(client, {
        limit: q.limit,
        offset: q.offset,
        tenantId: q.tenantId,
        propertyId: q.propertyId,
        listingId: q.listingId,
        status: q.status as any,
      })
    );

    return { ok: true, data, paging: { limit: q.limit, offset: q.offset } };
  });

  app.post("/v1/tenancies", { preHandler: [app.authenticate] }, async (req) => {
    const body = createTenancyBodySchema.parse((req as any).body ?? {});
    const ctx = getRlsCtx(req);

    const result = await withRlsTransaction(ctx, (client) =>
      createTenancy(client, {
        tenantId: body.tenantId,
        propertyId: body.propertyId,
        listingId: body.listingId ?? null,

        rentAmount: body.rentAmount,
        securityDeposit: body.securityDeposit ?? null,

        startDate: body.startDate,
        nextDueDate: body.nextDueDate,

        paymentCycle: (body.paymentCycle as any) ?? null,
        status: (body.status as any) ?? null,

        terminationReason: body.terminationReason ?? null,
      })
    );

    return { ok: true, data: result.row, reused: result.reused, patched: result.patched };
  });
}