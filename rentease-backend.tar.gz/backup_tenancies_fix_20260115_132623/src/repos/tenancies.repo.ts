import type { PoolClient } from "pg";

export type TenancyStatus = "active" | "ended" | "terminated" | "pending_start";

export type TenancyRow = {
  id: string;

  tenant_id: string;
  property_id: string;
  listing_id: string | null;

  rent_amount: string;
  security_deposit: string | null;
  payment_cycle: string | null;

  start_date: string; // YYYY-MM-DD
  end_date: string | null; // YYYY-MM-DD or null
  next_due_date: string; // YYYY-MM-DD

  notice_period_days: number | null;
  status: TenancyStatus | null;

  termination_reason: string | null;
  late_fee_percentage: string | null;
  grace_period_days: number | null;

  created_at: string;
  updated_at: string;
  deleted_at: string | null;

  version: number | null;
};

export type InsertTenancyArgs = {
  tenant_id: string;
  property_id: string;
  listing_id?: string | null;

  rent_amount: number;
  security_deposit?: number | null;

  start_date: string; // YYYY-MM-DD
  next_due_date: string; // YYYY-MM-DD

  payment_cycle?: string | null;
  status?: TenancyStatus | null;

  termination_reason?: string | null;
};

// Reusable SELECT list (casts DATE -> TEXT so API returns "YYYY-MM-DD")
const TENANCY_SELECT = `
  id,
  tenant_id,
  property_id,
  listing_id,
  rent_amount,
  security_deposit,
  payment_cycle,
  start_date::text    AS start_date,
  end_date::text      AS end_date,
  next_due_date::text AS next_due_date,
  notice_period_days,
  status,
  termination_reason,
  late_fee_percentage,
  grace_period_days,
  created_at,
  updated_at,
  deleted_at,
  version
`;

const OPEN_STATUSES: TenancyStatus[] = ["active", "pending_start"];

export async function findOpenTenancyByTenantProperty(
  client: PoolClient,
  tenantId: string,
  propertyId: string
): Promise<TenancyRow | null> {
  const { rows } = await client.query<TenancyRow>(
    `
    SELECT ${TENANCY_SELECT}
    FROM public.tenancies
    WHERE tenant_id = $1
      AND property_id = $2
      AND deleted_at IS NULL
      AND status = ANY($3::tenancy_status[])
    ORDER BY created_at DESC
    LIMIT 1;
    `,
    [tenantId, propertyId, OPEN_STATUSES]
  );
  return rows[0] ?? null;
}

export async function patchOpenTenancyMissingFields(
  client: PoolClient,
  tenancyId: string,
  patch: {
    listing_id?: string | null;
    security_deposit?: number | null;
    termination_reason?: string | null;
  }
): Promise<{ row: TenancyRow; patched: boolean }> {
  const { rows } = await client.query<TenancyRow & { patched: boolean }>(
    `
    WITH prev AS (
      SELECT
        id,
        listing_id,
        security_deposit,
        termination_reason
      FROM public.tenancies
      WHERE id = $1
      FOR UPDATE
    ),
    upd AS (
      UPDATE public.tenancies t
      SET
        listing_id = COALESCE(prev.listing_id, $2::uuid),
        security_deposit = COALESCE(prev.security_deposit, $3::numeric),
        termination_reason = COALESCE(prev.termination_reason, $4::text),
        updated_at = CASE
          WHEN
            (prev.listing_id IS NULL AND $2::uuid IS NOT NULL)
            OR (prev.security_deposit IS NULL AND $3::numeric IS NOT NULL)
            OR (prev.termination_reason IS NULL AND $4::text IS NOT NULL)
          THEN NOW()
          ELSE t.updated_at
        END
      FROM prev
      WHERE t.id = prev.id
      RETURNING
        ${TENANCY_SELECT},
        (
          (prev.listing_id IS NULL AND $2::uuid IS NOT NULL)
          OR (prev.security_deposit IS NULL AND $3::numeric IS NOT NULL)
          OR (prev.termination_reason IS NULL AND $4::text IS NOT NULL)
        ) AS patched
    )
    SELECT * FROM upd;
    `,
    [
      tenancyId,
      patch.listing_id ?? null,
      patch.security_deposit ?? null,
      patch.termination_reason ?? null,
    ]
  );

  const row = rows[0]!;
  const patched = (row as any).patched === true;
  delete (row as any).patched;

  return { row, patched };
}

export async function insertTenancy(
  client: PoolClient,
  data: InsertTenancyArgs
): Promise<TenancyRow> {
  const { rows } = await client.query<TenancyRow>(
    `
    INSERT INTO public.tenancies (
      tenant_id,
      property_id,
      listing_id,
      rent_amount,
      security_deposit,
      start_date,
      next_due_date,
      payment_cycle,
      status,
      termination_reason
    )
    VALUES (
      $1, $2, $3,
      $4::numeric,
      $5::numeric,
      $6::date,
      $7::date,
      COALESCE($8::payment_cycle, 'monthly'::payment_cycle),
      COALESCE($9::tenancy_status, 'pending_start'::tenancy_status),
      $10
    )
    RETURNING ${TENANCY_SELECT};
    `,
    [
      data.tenant_id,
      data.property_id,
      data.listing_id ?? null,
      data.rent_amount,
      data.security_deposit ?? null,
      data.start_date,
      data.next_due_date,
      data.payment_cycle ?? null,
      data.status ?? null,
      data.termination_reason ?? null,
    ]
  );

  return rows[0]!;
}

export async function createTenancyIdempotent(
  client: PoolClient,
  data: InsertTenancyArgs
): Promise<{ row: TenancyRow; reused: boolean; patched: boolean }> {
  // 1) Fast path: open tenancy exists → patch missing fields only
  const existing = await findOpenTenancyByTenantProperty(client, data.tenant_id, data.property_id);
  if (existing) {
    const patchedRes = await patchOpenTenancyMissingFields(client, existing.id, {
      listing_id: data.listing_id ?? null,
      security_deposit: data.security_deposit ?? null,
      termination_reason: data.termination_reason ?? null,
    });
    return { row: patchedRes.row, reused: true, patched: patchedRes.patched };
  }

  // 2) No open tenancy → insert
  try {
    const row = await insertTenancy(client, data);
    return { row, reused: false, patched: false };
  } catch (err: any) {
    // 3) Race-safe: another request inserted first (partial unique index violation)
    if (err?.code === "23505") {
      const again = await findOpenTenancyByTenantProperty(client, data.tenant_id, data.property_id);
      if (again) {
        const patchedRes = await patchOpenTenancyMissingFields(client, again.id, {
          listing_id: data.listing_id ?? null,
          security_deposit: data.security_deposit ?? null,
          termination_reason: data.termination_reason ?? null,
        });
        return { row: patchedRes.row, reused: true, patched: patchedRes.patched };
      }
    }
    throw err;
  }
}

export async function listTenancies(
  client: PoolClient,
  args: {
    limit: number;
    offset: number;
    tenant_id?: string;
    property_id?: string;
    listing_id?: string;
    status?: TenancyStatus;
  }
): Promise<TenancyRow[]> {
  const where: string[] = ["deleted_at IS NULL"];
  const params: any[] = [];
  let i = 1;

  if (args.tenant_id) {
    where.push(`tenant_id = $${i++}`);
    params.push(args.tenant_id);
  }
  if (args.property_id) {
    where.push(`property_id = $${i++}`);
    params.push(args.property_id);
  }
  if (args.listing_id) {
    where.push(`listing_id = $${i++}`);
    params.push(args.listing_id);
  }
  if (args.status) {
    where.push(`status = $${i++}::tenancy_status`);
    params.push(args.status);
  }

  params.push(args.limit);
  const limitIdx = i++;
  params.push(args.offset);
  const offsetIdx = i++;

  const { rows } = await client.query<TenancyRow>(
    `
    SELECT ${TENANCY_SELECT}
    FROM public.tenancies
    WHERE ${where.join(" AND ")}
    ORDER BY created_at DESC
    LIMIT $${limitIdx} OFFSET $${offsetIdx};
    `,
    params
  );

  return rows;
}