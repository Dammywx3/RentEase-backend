// src/schemas/tenancies.schema.ts
import { z } from "zod";

export const tenancyStatusSchema = z.enum([
  "active",
  "ended",
  "terminated",
  "pending_start",
]);

const dateOnly = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Expected YYYY-MM-DD");

export const createTenancyBodySchema = z.object({
  tenantId: z.string().uuid(),
  propertyId: z.string().uuid(),
  listingId: z.string().uuid().nullable().optional(),

  rentAmount: z.number().positive(),
  securityDeposit: z.number().nonnegative().nullable().optional(),

  startDate: dateOnly,
  nextDueDate: dateOnly,

  paymentCycle: z.string().optional(),
  status: tenancyStatusSchema.optional(),

  terminationReason: z.string().max(5000).nullable().optional(),
});

export const listTenanciesQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(10),
  offset: z.coerce.number().int().min(0).default(0),

  tenantId: z.string().uuid().optional(),
  propertyId: z.string().uuid().optional(),
  listingId: z.string().uuid().optional(),
  status: tenancyStatusSchema.optional(),
});

// ✅ Export TS types (THIS fixes your red underline type issues)
export type CreateTenancyBody = z.infer<typeof createTenancyBodySchema>;
export type ListTenanciesQuery = z.infer<typeof listTenanciesQuerySchema>;
