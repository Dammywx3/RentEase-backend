import "fastify";
import "@fastify/jwt";
import type { JwtPayload } from "../plugins/jwt.js";
import type { preHandlerHookHandler } from "fastify";

declare module "@fastify/jwt" {
  interface FastifyJWT {
    payload: JwtPayload;
    user: JwtPayload;
  }
}

declare module "fastify" {
  interface FastifyInstance {
    authenticate: preHandlerHookHandler;
  }

  interface FastifyRequest {
    user?: JwtPayload;

    rls?: {
      userId?: string;
      organizationId?: string;
    };

    auth?: {
      userId?: string;
      sub?: string;
    };
  }
}