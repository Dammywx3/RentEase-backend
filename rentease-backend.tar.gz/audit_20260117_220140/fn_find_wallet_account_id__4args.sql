        CREATE OR REPLACE FUNCTION public.find_wallet_account_id(p_org uuid, p_beneficiary_kind text, p_user_id uuid, p_currency text DEFAULT NULL::text)
         RETURNS uuid
         LANGUAGE plpgsql
1       AS $function$
2       DECLARE
3         v_id uuid;
4         v_cur text := NULLIF(trim(COALESCE(p_currency,'')), '');
5       BEGIN
6         -- Normalize currency (optional)
7         IF v_cur IS NOT NULL THEN
8           v_cur := upper(v_cur);
9         END IF;
10      
11        -- PLATFORM wallet lookup
12        IF p_beneficiary_kind = 'platform' THEN
13          IF v_cur IS NOT NULL THEN
14            SELECT wa.id
15            INTO v_id
16            FROM public.wallet_accounts wa
17            WHERE wa.organization_id = p_org
18              AND wa.is_platform_wallet = true
19              AND upper(COALESCE(wa.currency,'')) = v_cur
20            ORDER BY wa.created_at ASC
21            LIMIT 1;
22          ELSE
23            SELECT wa.id
24            INTO v_id
25            FROM public.wallet_accounts wa
26            WHERE wa.organization_id = p_org
27              AND wa.is_platform_wallet = true
28            ORDER BY wa.created_at ASC
29            LIMIT 1;
30          END IF;
31      
32          RETURN v_id;
33        END IF;
34      
35        -- USER wallet lookup
36        IF p_beneficiary_kind = 'user' THEN
37          IF p_user_id IS NULL THEN
38            RETURN NULL;
39          END IF;
40      
41          IF v_cur IS NOT NULL THEN
42            SELECT wa.id
43            INTO v_id
44            FROM public.wallet_accounts wa
45            WHERE wa.organization_id = p_org
46              AND wa.user_id = p_user_id
47              AND upper(COALESCE(wa.currency,'')) = v_cur
48            ORDER BY wa.created_at ASC
49            LIMIT 1;
50          ELSE
51            SELECT wa.id
52            INTO v_id
53            FROM public.wallet_accounts wa
54            WHERE wa.organization_id = p_org
55              AND wa.user_id = p_user_id
56            ORDER BY wa.created_at ASC
57            LIMIT 1;
58          END IF;
59      
60          RETURN v_id;
61        END IF;
62      
63        RETURN NULL;
64      END;
65      $function$
