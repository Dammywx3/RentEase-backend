        CREATE OR REPLACE FUNCTION public.find_wallet_account_id(p_org uuid, p_beneficiary_kind text, p_user_id uuid)
         RETURNS uuid
         LANGUAGE plpgsql
1       AS $function$
2       DECLARE
3         v_id uuid;
4       
5         -- detected column names (if they exist)
6         col_owner_kind text := NULL;
7         col_user_id text := NULL;
8         has_deleted_at boolean := false;
9       
10        q text;
11        del_filter text := '';
12      BEGIN
13        -- detect deleted_at
14        SELECT EXISTS (
15          SELECT 1 FROM information_schema.columns
16          WHERE table_schema='public'
17            AND table_name='wallet_accounts'
18            AND column_name='deleted_at'
19        )
20        INTO has_deleted_at;
21      
22        IF has_deleted_at THEN
23          del_filter := ' AND wa.deleted_at IS NULL ';
24        ELSE
25          del_filter := '';
26        END IF;
27      
28        -- detect "platform/user" discriminator column (optional)
29        IF EXISTS (
30          SELECT 1 FROM information_schema.columns
31          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='owner_kind'
32        ) THEN
33          col_owner_kind := 'owner_kind';
34        ELSIF EXISTS (
35          SELECT 1 FROM information_schema.columns
36          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='owner_type'
37        ) THEN
38          col_owner_kind := 'owner_type';
39        ELSIF EXISTS (
40          SELECT 1 FROM information_schema.columns
41          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='wallet_owner_kind'
42        ) THEN
43          col_owner_kind := 'wallet_owner_kind';
44        ELSIF EXISTS (
45          SELECT 1 FROM information_schema.columns
46          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='account_kind'
47        ) THEN
48          col_owner_kind := 'account_kind';
49        END IF;
50      
51        -- detect user id column
52        IF EXISTS (
53          SELECT 1 FROM information_schema.columns
54          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='owner_user_id'
55        ) THEN
56          col_user_id := 'owner_user_id';
57        ELSIF EXISTS (
58          SELECT 1 FROM information_schema.columns
59          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='user_id'
60        ) THEN
61          col_user_id := 'user_id';
62        ELSIF EXISTS (
63          SELECT 1 FROM information_schema.columns
64          WHERE table_schema='public' AND table_name='wallet_accounts' AND column_name='owner_id'
65        ) THEN
66          col_user_id := 'owner_id';
67        END IF;
68      
69        -- PLATFORM wallet lookup
70        IF p_beneficiary_kind = 'platform' THEN
71          -- Prefer explicit kind/type column if it exists
72          IF col_owner_kind IS NOT NULL THEN
73            q := format(
74              'SELECT wa.id
75               FROM public.wallet_accounts wa
76               WHERE wa.organization_id = $1
77                 AND wa.%I::text = ''platform'' %s
78               ORDER BY wa.created_at ASC
79               LIMIT 1',
80              col_owner_kind,
81              del_filter
82            );
83            EXECUTE q INTO v_id USING p_org;
84            IF v_id IS NOT NULL THEN
85              RETURN v_id;
86            END IF;
87          END IF;
88      
89          -- Fallback: platform wallet is a row with NULL user owner (your schema uses user_id NULL + is_platform_wallet=true)
90          IF col_user_id IS NOT NULL THEN
91            q := format(
92              'SELECT wa.id
93               FROM public.wallet_accounts wa
94               WHERE wa.organization_id = $1
95                 AND wa.%I IS NULL %s
96               ORDER BY wa.created_at ASC
97               LIMIT 1',
98              col_user_id,
99              del_filter
100           );
101           EXECUTE q INTO v_id USING p_org;
102           RETURN v_id;
103         END IF;
104     
105         RETURN NULL;
106       END IF;
107     
108       -- USER wallet lookup
109       IF p_beneficiary_kind = 'user' THEN
110         IF col_user_id IS NULL THEN
111           RETURN NULL;
112         END IF;
113     
114         q := format(
115           'SELECT wa.id
116            FROM public.wallet_accounts wa
117            WHERE wa.organization_id = $1
118              AND wa.%I = $2 %s
119            ORDER BY wa.created_at ASC
120            LIMIT 1',
121           col_user_id,
122           del_filter
123         );
124         EXECUTE q INTO v_id USING p_org, p_user_id;
125         RETURN v_id;
126       END IF;
127     
128       RETURN NULL;
129     END;
130     $function$
