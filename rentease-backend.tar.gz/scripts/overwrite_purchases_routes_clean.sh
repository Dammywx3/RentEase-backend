#!/usr/bin/env bash
set -euo pipefail

FILE="src/routes/purchases.routes.ts"
ts="$(date +%Y%m%d_%H%M%S)"
mkdir -p scripts/.bak

if [[ -f "$FILE" ]]; then
  cp "$FILE" "scripts/.bak/purchases.routes.ts.bak.$ts"
  echo "✅ backup -> scripts/.bak/purchases.routes.ts.bak.$ts"
fi

cat > "$FILE" <<'TS'
import type { FastifyInstance } from "fastify";

import { payPropertyPurchase } from "../services/purchase_payments.service.js";
import { refundPropertyPurchase } from "../services/purchase_refunds.service.js";

/**
 * Purchases Routes (BUY FLOW)
 * Mounted with prefix "/v1" from routes/index.ts
 */
export default async function purchasesRoutes(fastify: FastifyInstance) {
  // ------------------------------------------------------------
  // GET /purchases (list)
  // ------------------------------------------------------------
  fastify.get("/purchases", async (request, reply) => {
    const orgId = String(request.headers["x-organization-id"] || "");
    if (!orgId) {
      return reply.code(400).send({
        ok: false,
        error: "ORG_REQUIRED",
        message: "x-organization-id required",
      });
    }

    const client = await fastify.pg.connect();
    try {
      const { rows } = await client.query(
        `
        select
          pp.id,
          pp.organization_id,
          pp.property_id,
          pp.listing_id,
          pp.buyer_id,
          pp.seller_id,
          pp.agreed_price::text as agreed_price,
          pp.currency,
          pp.status::text as status,
          pp.payment_status::text as payment_status,
          pp.paid_at::text as paid_at,
          pp.paid_amount::text as paid_amount,
          pp.refunded_at::text as refunded_at,
          pp.refunded_amount::text as refunded_amount,
          pp.created_at::text as created_at,
          pp.updated_at::text as updated_at,

          exists (
            select 1 from public.property_purchase_payments ppp
            where ppp.purchase_id = pp.id
          ) as has_payment_link,

          (
            select count(*)
            from public.wallet_transactions wt
            where wt.reference_type='purchase'
              and wt.reference_id=pp.id
              and wt.txn_type in (
                'credit_payee'::wallet_transaction_type,
                'credit_platform_fee'::wallet_transaction_type,
                'debit_payee'::wallet_transaction_type,
                'debit_platform_fee'::wallet_transaction_type
              )
          ) as ledger_txn_count

        from public.property_purchases pp
        where pp.organization_id = $1::uuid
          and pp.deleted_at is null
        order by pp.created_at desc
        limit 50;
        `,
        [orgId]
      );

      return reply.send({ ok: true, data: rows });
    } finally {
      client.release();
    }
  });

  // ------------------------------------------------------------
  // GET /purchases/:purchaseId (detail)
  // ------------------------------------------------------------
  fastify.get<{ Params: { purchaseId: string } }>(
    "/purchases/:purchaseId",
    async (request, reply) => {
      const orgId = String(request.headers["x-organization-id"] || "");
      if (!orgId) {
        return reply.code(400).send({
          ok: false,
          error: "ORG_REQUIRED",
          message: "x-organization-id required",
        });
      }

      const { purchaseId } = request.params;

      const client = await fastify.pg.connect();
      try {
        const { rows } = await client.query(
          `
          select
            pp.*,
            pp.status::text as status_text,
            pp.payment_status::text as payment_status_text,

            coalesce((
              select jsonb_agg(jsonb_build_object(
                'payment_id', p.id,
                'amount', p.amount,
                'currency', p.currency,
                'status', p.status::text,
                'transaction_reference', p.transaction_reference,
                'created_at', p.created_at
              ) order by p.created_at desc)
              from public.property_purchase_payments link
              join public.payments p on p.id = link.payment_id
              where link.purchase_id = pp.id
            ), '[]'::jsonb) as payments,

            coalesce((
              select jsonb_agg(jsonb_build_object(
                'txn_type', wt.txn_type::text,
                'amount', wt.amount,
                'currency', wt.currency,
                'created_at', wt.created_at
              ) order by wt.created_at asc)
              from public.wallet_transactions wt
              where wt.reference_type='purchase'
                and wt.reference_id=pp.id
            ), '[]'::jsonb) as ledger

          from public.property_purchases pp
          where pp.id = $1::uuid
            and pp.organization_id = $2::uuid
            and pp.deleted_at is null
          limit 1;
          `,
          [purchaseId, orgId]
        );

        const row = rows[0];
        if (!row) {
          return reply.code(404).send({
            ok: false,
            error: "NOT_FOUND",
            message: "Purchase not found",
          });
        }

        return reply.send({ ok: true, data: row });
      } finally {
        client.release();
      }
    }
  );

  // ------------------------------------------------------------
  // POST /purchases/:purchaseId/pay
  // body: { paymentMethod: "card"|"bank_transfer"|"wallet", amount?: number }
  // ------------------------------------------------------------
  fastify.post<{
    Params: { purchaseId: string };
    Body: { paymentMethod: "card" | "bank_transfer" | "wallet"; amount?: number };
  }>("/purchases/:purchaseId/pay", async (request, reply) => {
    const orgId = String(request.headers["x-organization-id"] || "");
    if (!orgId) {
      return reply
        .code(400)
        .send({ ok: false, error: "ORG_REQUIRED", message: "x-organization-id required" });
    }

    const { purchaseId } = request.params;
    const paymentMethod = request.body?.paymentMethod;
    const amount = request.body?.amount;

    if (!paymentMethod) {
      return reply.code(400).send({
        ok: false,
        error: "PAYMENT_METHOD_REQUIRED",
        message: "paymentMethod is required",
      });
    }

    const client = await fastify.pg.connect();
    try {
      const result = await payPropertyPurchase(client, {
        organizationId: orgId,
        purchaseId,
        paymentMethod,
        amount: typeof amount === "number" ? amount : undefined,
      });

      return reply.send({ ok: true, data: result });
    } catch (err: any) {
      return reply.code(400).send({
        ok: false,
        error: err?.code || "PAY_FAILED",
        message: err?.message || "Payment failed",
      });
    } finally {
      client.release();
    }
  });

  // ------------------------------------------------------------
  // POST /purchases/:purchaseId/refund
  // body: { refundMethod: "card"|"bank_transfer"|"wallet", amount?: number }
  // NOTE: service currently expects { reason?: string }, so we map refundMethod -> reason
  // ------------------------------------------------------------
  fastify.post<{
    Params: { purchaseId: string };
    Body: { refundMethod: "card" | "bank_transfer" | "wallet"; amount?: number };
  }>("/purchases/:purchaseId/refund", async (request, reply) => {
    const orgId = String(request.headers["x-organization-id"] || "");
    if (!orgId) {
      return reply
        .code(400)
        .send({ ok: false, error: "ORG_REQUIRED", message: "x-organization-id required" });
    }

    const { purchaseId } = request.params;
    const refundMethod = request.body?.refundMethod;
    const amount = request.body?.amount;

    if (!refundMethod) {
      return reply.code(400).send({
        ok: false,
        error: "REFUND_METHOD_REQUIRED",
        message: "refundMethod is required",
      });
    }

    const client = await fastify.pg.connect();
    try {
      const result = await refundPropertyPurchase(client, {
        organizationId: orgId,
        purchaseId,
        amount: typeof amount === "number" ? amount : undefined,
        reason: refundMethod,
      });

      return reply.send({ ok: true, data: result });
    } catch (err: any) {
      return reply.code(400).send({
        ok: false,
        error: err?.code || "REFUND_FAILED",
        message: err?.message || "Refund failed",
      });
    } finally {
      client.release();
    }
  });
}
TS

echo "✅ Rewrote: $FILE"
echo "🔎 Typecheck..."
npx -y tsc -p tsconfig.json --noEmit
echo "✅ OK"
echo "NEXT: npm run dev"
