#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/src/routes/rent_invoices.ts"

if [ ! -f "$FILE" ]; then
  echo "ERROR: $FILE not found"
  exit 1
fi

mkdir -p "$ROOT/scripts/.bak"
ts="$(date +%Y%m%d_%H%M%S)"
cp "$FILE" "$ROOT/scripts/.bak/rent_invoices.ts.bak.$ts"
echo "✅ backup -> scripts/.bak/rent_invoices.ts.bak.$ts"

perl -0777 -i -pe '
  # Replace the whole applyDbContext(...) function with a safe sequential version
  s{
    async\s+function\s+applyDbContext\s*\(\s*client\s*:\s*any\s*,\s*req\s*:\s*any\s*\)\s*\{[\s\S]*?\n\}
  }{
async function applyDbContext(client: any, req: any) {
  const orgId =
    req?.headers?.["x-organization-id"] ||
    req?.headers?.["X-Organization-Id"] ||
    req?.headers?.["x-organization-id".toLowerCase()];

  const userId = req?.user?.sub || null;
  const role = req?.user?.role || null;

  if (!orgId) {
    const e: any = new Error("Missing x-organization-id header");
    e.code = "ORG_ID_MISSING";
    throw e;
  }

  // Postgres custom GUC names:
  // - MUST contain a dot
  // - MUST NOT contain dashes (-)
  // Also: do NOT use one big SELECT with commas (avoid syntax issues from prior patches).
  const org = String(orgId);
  const uid = userId ? String(userId) : "";
  const r = role ? String(role) : "";

  await client.query("SELECT set_config('request.organization_id', $1, true);", [org]);
  await client.query("SELECT set_config('request.org_id', $1, true);", [org]);
  await client.query("SELECT set_config('app.organization_id', $1, true);", [org]);
  await client.query("SELECT set_config('app.org_id', $1, true);", [org]);
  await client.query("SELECT set_config('rentease.organization_id', $1, true);", [org]);
  await client.query("SELECT set_config('rentease.org_id', $1, true);", [org]);

  await client.query("SELECT set_config('request.user_id', $1, true);", [uid]);
  await client.query("SELECT set_config('app.user_id', $1, true);", [uid]);
  await client.query("SELECT set_config('rentease.user_id', $1, true);", [uid]);
  await client.query("SELECT set_config('request.jwt.claim.sub', $1, true);", [uid]);

  await client.query("SELECT set_config('request.user_role', $1, true);", [r]);
  await client.query("SELECT set_config('app.user_role', $1, true);", [r]);
  await client.query("SELECT set_config('rentease.user_role', $1, true);", [r]);
}
}sx or die "Could not find applyDbContext(client:any, req:any) in $ARGV\n";
' "$FILE"

echo "✅ Patched applyDbContext() to sequential set_config calls"
echo "➡️ Restart server: npm run dev"
