#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cat > "$ROOT/src/routes/rent_invoices.ts" <<'TS'
import type { FastifyInstance } from "fastify";
import { z } from "zod";

import { pool } from "../config/database.js";
import { generateRentInvoiceForTenancy, getRentInvoices } from "../services/rent_invoices.service.js";

const InvoiceStatus = z.enum(["draft", "issued", "paid", "overdue", "void", "cancelled"]);

function getOrgId(req: any): string | null {
  const h = req.headers?.["x-organization-id"];
  if (typeof h === "string" && h.length) return h;
  if (req.user?.org && typeof req.user.org === "string") return req.user.org;
  if (req.user?.organization_id && typeof req.user.organization_id === "string") return req.user.organization_id;
  return null;
}

function getUserId(req: any): string | null {
  // common claim keys
  if (typeof req.user?.sub === "string") return req.user.sub;
  if (typeof req.user?.id === "string") return req.user.id;
  if (typeof req.user?.user_id === "string") return req.user.user_id;
  if (typeof req.user?.uid === "string") return req.user.uid;

  // sometimes the payload might literally be the uuid string
  if (typeof req.user === "string") return req.user;

  return null;
}

function getRole(req: any): string {
  if (typeof req.user?.role === "string") return req.user.role;
  return "tenant";
}

async function setDbContext(client: any, req: any) {
  const orgId = getOrgId(req);
  const userId = getUserId(req);
  const role = getRole(req);

  if (!orgId) {
    const err: any = new Error("Missing x-organization-id header");
    err.code = "ORG_ID_MISSING";
    throw err;
  }
  if (!userId) {
    const err: any = new Error("Missing authenticated user id (req.user / token claims)");
    err.code = "USER_ID_MISSING";
    throw err;
  }

  await client.query(
    `
    SELECT
      set_config('request.jwt.claim.sub', $1, true),
      set_config('request.jwt.claim.role', $2, true),
      set_config('request.header.x-organization-id', $3, true),
      set_config('app.current_user_uuid', $1, true),
      set_config('app.current_organization_uuid', $3, true);
    `,
    [userId, role, orgId]
  );

  return { orgId, userId, role };
}

export async function rentInvoicesRoutes(app: FastifyInstance) {
  // ✅ AUTH GUARD: prefer app.authenticate if your jwt plugin defines it, else fallback to req.jwtVerify()
  const authGuard =
    (app as any).authenticate ??
    (async (req: any, reply: any) => {
      try {
        if (typeof req.jwtVerify !== "function") {
          return reply
            .code(500)
            .send({ ok: false, error: "JWT_NOT_CONFIGURED", message: "req.jwtVerify() not found. JWT plugin not registered." });
        }
        await req.jwtVerify();
      } catch (e: any) {
        return reply.code(401).send({ ok: false, error: "UNAUTHORIZED", message: e?.message ?? "Invalid token" });
      }
    });

  // Generate invoice for a tenancy
  app.post(
    "/v1/tenancies/:id/rent-invoices/generate",
    { preHandler: authGuard },
    async (req, reply) => {
      const params = z.object({ id: z.string().uuid() }).parse((req as any).params);

      const body = z
        .object({
          periodStart: z.string(),
          periodEnd: z.string(),
          dueDate: z.string(),

          subtotal: z.number().optional(),
          lateFeeAmount: z.number().nullable().optional(),
          currency: z.string().nullable().optional(),
          status: InvoiceStatus.nullable().optional(),
          notes: z.string().nullable().optional(),
        })
        .parse((req as any).body);

      const client = await pool.connect();
      try {
        await client.query("BEGIN");
        await setDbContext(client, req);

        const res = await generateRentInvoiceForTenancy(client, {
          tenancyId: params.id,
          periodStart: body.periodStart,
          periodEnd: body.periodEnd,
          dueDate: body.dueDate,
          subtotal: body.subtotal,
          lateFeeAmount: body.lateFeeAmount,
          currency: body.currency,
          status: body.status ?? undefined,
          notes: body.notes ?? undefined,
        });

        await client.query("COMMIT");
        return reply.send({ ok: true, reused: res.reused, data: res.row });
      } catch (err: any) {
        await client.query("ROLLBACK");
        return reply
          .code(500)
          .send({ ok: false, error: err?.code ?? "INTERNAL_ERROR", message: err?.message ?? String(err) });
      } finally {
        client.release();
      }
    }
  );

  // List invoices
  app.get(
    "/v1/rent-invoices",
    { preHandler: authGuard },
    async (req, reply) => {
      const q = z
        .object({
          limit: z.coerce.number().min(1).max(200).default(20),
          offset: z.coerce.number().min(0).default(0),
          tenancyId: z.string().uuid().optional(),
          tenantId: z.string().uuid().optional(),
          propertyId: z.string().uuid().optional(),
          status: InvoiceStatus.optional(),
        })
        .parse((req as any).query);

      const client = await pool.connect();
      try {
        await setDbContext(client, req);

        const data = await getRentInvoices(client, {
          limit: q.limit,
          offset: q.offset,
          tenancyId: q.tenancyId,
          tenantId: q.tenantId,
          propertyId: q.propertyId,
          status: q.status,
        });

        return reply.send({ ok: true, data, paging: { limit: q.limit, offset: q.offset } });
      } catch (err: any) {
        return reply
          .code(500)
          .send({ ok: false, error: err?.code ?? "INTERNAL_ERROR", message: err?.message ?? String(err) });
      } finally {
        client.release();
      }
    }
  );
}
TS

echo "✅ Patched src/routes/rent_invoices.ts to enforce auth and populate req.user."
echo "➡️ Restart: npm run dev"
