#!/usr/bin/env bash
set -euo pipefail

API="${API:-http://127.0.0.1:4000}"
SECRET="${PAYSTACK_SECRET_KEY:-${SECRET:-}}"
BODY='{"event":"ping","data":{}}'

if [ -z "${SECRET:-}" ]; then
  echo "❌ Missing secret. Run like:"
  echo '   PAYSTACK_SECRET_KEY="sk_test_..." bash scripts/test_paystack_webhook.sh'
  exit 1
fi

# Compute signature over EXACT BYTES that will be sent (no newline)
SIG="$(printf '%s' "$BODY" | SECRET="$SECRET" node -e '
  const crypto=require("crypto");
  const secret=process.env.SECRET||"";
  const chunks=[];
  process.stdin.on("data",d=>chunks.push(d));
  process.stdin.on("end",()=>{
    const buf=Buffer.concat(chunks);
    process.stdout.write(crypto.createHmac("sha512", secret).update(buf).digest("hex"));
  });
')"

echo "-> POST $API/webhooks/paystack"
printf '%s' "$BODY" | curl -sS -i -X POST "$API/webhooks/paystack" \
  -H "Content-Type: application/json" \
  -H "x-paystack-signature: $SIG" \
  --data-binary @- | sed -n '1,60p'
