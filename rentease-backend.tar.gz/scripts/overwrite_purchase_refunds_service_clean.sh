#!/usr/bin/env bash
set -euo pipefail

TS="$(date +%Y%m%d_%H%M%S)"
mkdir -p scripts/.bak

FILE="src/services/purchase_refunds.service.ts"

if [ -f "$FILE" ]; then
  cp "$FILE" "scripts/.bak/purchase_refunds.service.ts.bak.$TS"
  echo "✅ backup -> scripts/.bak/purchase_refunds.service.ts.bak.$TS"
else
  echo "ℹ️ $FILE not found, will create it"
fi

cat > "$FILE" <<'TS'
import type { PoolClient } from "pg";
import { computePlatformFeeSplit } from "../config/fees.config.js";

export type RefundMethod = "card" | "bank_transfer" | "wallet";

export type PropertyPurchaseRow = {
  id: string;
  organization_id: string;
  property_id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  agreed_price: string;
  currency: string;
  status: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;

  payment_status: string;
  paid_at: string | null;
  paid_amount: string | null;
  last_payment_id: string | null;

  refunded_at: string | null;
  refunded_amount: string | null;
};

const PURCHASE_SELECT = `
  pp.id,
  pp.organization_id,
  pp.property_id,
  pp.listing_id,
  pp.buyer_id,
  pp.seller_id,
  pp.agreed_price::text AS agreed_price,
  pp.currency,
  pp.status::text AS status,
  pp.created_at::text AS created_at,
  pp.updated_at::text AS updated_at,
  pp.deleted_at::text AS deleted_at,

  pp.payment_status::text AS payment_status,
  pp.paid_at::text AS paid_at,
  pp.paid_amount::text AS paid_amount,
  pp.last_payment_id::text AS last_payment_id,

  pp.refunded_at::text AS refunded_at,
  pp.refunded_amount::text AS refunded_amount
`;

async function getPurchase(
  client: PoolClient,
  args: { organizationId: string; purchaseId: string }
): Promise<PropertyPurchaseRow> {
  const { rows } = await client.query<PropertyPurchaseRow>(
    `
    SELECT ${PURCHASE_SELECT}
    FROM public.property_purchases pp
    WHERE pp.id = $1::uuid
      AND pp.organization_id = $2::uuid
      AND pp.deleted_at IS NULL
    LIMIT 1;
    `,
    [args.purchaseId, args.organizationId]
  );

  const row = rows[0];
  if (!row) {
    const e: any = new Error("Purchase not found");
    e.code = "PURCHASE_NOT_FOUND";
    throw e;
  }
  return row;
}

async function getPlatformWalletAccountId(client: PoolClient, organizationId: string): Promise<string> {
  const { rows } = await client.query<{ id: string }>(
    `
    SELECT id::text AS id
    FROM public.wallet_accounts
    WHERE organization_id = $1::uuid
      AND is_platform_wallet = true
    LIMIT 1;
    `,
    [organizationId]
  );
  const id = rows[0]?.id;
  if (!id) {
    const e: any = new Error("Platform wallet not found");
    e.code = "PLATFORM_WALLET_NOT_FOUND";
    throw e;
  }
  return id;
}

async function getUserWalletAccountId(client: PoolClient, organizationId: string, userId: string): Promise<string> {
  const { rows } = await client.query<{ id: string }>(
    `
    SELECT id::text AS id
    FROM public.wallet_accounts
    WHERE organization_id = $1::uuid
      AND user_id = $2::uuid
      AND is_platform_wallet = false
    LIMIT 1;
    `,
    [organizationId, userId]
  );
  const id = rows[0]?.id;
  if (!id) {
    const e: any = new Error("User wallet not found");
    e.code = "USER_WALLET_NOT_FOUND";
    throw e;
  }
  return id;
}

async function hasRefundDebits(client: PoolClient, organizationId: string, purchaseId: string) {
  const { rows } = await client.query<{ txn_type: string; cnt: string }>(
    `
    SELECT wt.txn_type::text AS txn_type, count(*)::text AS cnt
    FROM public.wallet_transactions wt
    WHERE wt.organization_id = $1::uuid
      AND wt.reference_type = 'purchase'
      AND wt.reference_id = $2::uuid
      AND wt.txn_type IN (
        'debit_payee'::wallet_transaction_type,
        'debit_platform_fee'::wallet_transaction_type
      )
    GROUP BY wt.txn_type;
    `,
    [organizationId, purchaseId]
  );

  const hasPayee = rows.some((r) => r.txn_type === "debit_payee" && Number(r.cnt) > 0);
  const hasFee = rows.some((r) => r.txn_type === "debit_platform_fee" && Number(r.cnt) > 0);
  return { hasPayee, hasFee };
}

async function upsertRefundMilestones(
  client: PoolClient,
  args: { organizationId: string; purchaseId: string; amount: number; lastPaymentId: string | null }
) {
  await client.query(
    `
    UPDATE public.property_purchases
    SET
      payment_status = 'refunded'::purchase_payment_status,
      refunded_at = COALESCE(refunded_at, NOW()),
      refunded_amount = COALESCE(refunded_amount, 0) + $1::numeric,
      updated_at = NOW()
    WHERE id = $2::uuid
      AND organization_id = $3::uuid
      AND deleted_at IS NULL;
    `,
    [args.amount, args.purchaseId, args.organizationId]
  );
}

async function insertDebitTxn(
  client: PoolClient,
  args: {
    organizationId: string;
    walletAccountId: string;
    txnType: "debit_platform_fee" | "debit_payee";
    amount: number;
    currency: string;
    purchaseId: string;
    note: string;
  }
) {
  // Insert only if this exact txn doesn't already exist (keeps idempotent)
  const { rows } = await client.query<{ exists: boolean }>(
    `
    SELECT EXISTS(
      SELECT 1
      FROM public.wallet_transactions wt
      WHERE wt.organization_id = $1::uuid
        AND wt.wallet_account_id = $2::uuid
        AND wt.reference_type = 'purchase'
        AND wt.reference_id = $3::uuid
        AND wt.txn_type = $4::wallet_transaction_type
    ) AS exists;
    `,
    [args.organizationId, args.walletAccountId, args.purchaseId, args.txnType]
  );

  if (rows?.[0]?.exists) return;

  await client.query(
    `
    INSERT INTO public.wallet_transactions (
      organization_id,
      wallet_account_id,
      txn_type,
      amount,
      currency,
      reference_type,
      reference_id,
      note,
      created_at
    )
    VALUES (
      $1::uuid,
      $2::uuid,
      $3::wallet_transaction_type,
      $4::numeric,
      $5,
      'purchase',
      $6::uuid,
      $7,
      NOW()
    );
    `,
    [
      args.organizationId,
      args.walletAccountId,
      args.txnType,
      args.amount,
      args.currency,
      args.purchaseId,
      args.note,
    ]
  );
}

export async function refundPropertyPurchase(
  client: PoolClient,
  args: {
    organizationId: string;
    purchaseId: string;
    amount?: number | null; // defaults to paid_amount/agreed_price
    reason?: string | null;
    refundMethod?: RefundMethod; // accepted for API symmetry; not used in DB logic
  }
): Promise<{
  purchase: PropertyPurchaseRow;
  alreadyRefunded: boolean;
  platformFeeReversed: number;
  sellerReversed: number;
}> {
  const purchase = await getPurchase(client, {
    organizationId: args.organizationId,
    purchaseId: args.purchaseId,
  });

  // Must be paid before refund (milestone-based)
  if (purchase.payment_status !== "paid") {
    const e: any = new Error(`Purchase not refundable because payment_status=${purchase.payment_status}`);
    e.code = "NOT_PAID";
    throw e;
  }

  const agreed = Number(purchase.agreed_price);
  const paidAmount = purchase.paid_amount ? Number(purchase.paid_amount) : agreed;
  const amount = typeof args.amount === "number" ? args.amount : paidAmount;

  if (Number(amount) !== Number(paidAmount)) {
    const e: any = new Error(`Refund.amount (${amount}) must equal paid_amount (${paidAmount})`);
    e.code = "AMOUNT_MISMATCH";
    throw e;
  }

  const currency = (purchase.currency ?? "USD") || "USD";

  // If already marked refunded OR already has both debit txns, be idempotent.
  const debits = await hasRefundDebits(client, args.organizationId, purchase.id);

  if (purchase.refunded_at || purchase.payment_status === "refunded" || (debits.hasPayee && debits.hasFee)) {
    // Ensure milestones are set even if caller is re-trying later
    await upsertRefundMilestones(client, {
      organizationId: args.organizationId,
      purchaseId: purchase.id,
      amount,
      lastPaymentId: purchase.last_payment_id ?? null,
    });

    const updated = await getPurchase(client, { organizationId: args.organizationId, purchaseId: purchase.id });
    return { purchase: updated, alreadyRefunded: true, platformFeeReversed: 0, sellerReversed: 0 };
  }

  const split = computePlatformFeeSplit({
    paymentKind: "buy",
    amount,
    currency,
  });

  // Reverse the exact amounts we credited on pay:
  // - debit platform wallet by platformFee
  // - debit seller wallet by payeeNet
  const platformWalletId = await getPlatformWalletAccountId(client, args.organizationId);
  const sellerWalletId = await getUserWalletAccountId(client, args.organizationId, purchase.seller_id);

  await insertDebitTxn(client, {
    organizationId: args.organizationId,
    walletAccountId: platformWalletId,
    txnType: "debit_platform_fee",
    amount: split.platformFee,
    currency,
    purchaseId: purchase.id,
    note: `Refund reversal: platform fee for purchase ${purchase.id}${args.reason ? ` (${args.reason})` : ""}`,
  });

  await insertDebitTxn(client, {
    organizationId: args.organizationId,
    walletAccountId: sellerWalletId,
    txnType: "debit_payee",
    amount: split.payeeNet,
    currency,
    purchaseId: purchase.id,
    note: `Refund reversal: seller payout for purchase ${purchase.id}${args.reason ? ` (${args.reason})` : ""}`,
  });

  // Mark refunded
  await upsertRefundMilestones(client, {
    organizationId: args.organizationId,
    purchaseId: purchase.id,
    amount,
    lastPaymentId: purchase.last_payment_id ?? null,
  });

  const updated = await getPurchase(client, {
    organizationId: args.organizationId,
    purchaseId: purchase.id,
  });

  return {
    purchase: updated,
    alreadyRefunded: false,
    platformFeeReversed: split.platformFee,
    sellerReversed: split.payeeNet,
  };
}
TS

echo "✅ rewrote: $FILE"
echo ""
echo "🔎 Typecheck..."
npx -y tsc -p tsconfig.json --noEmit
echo ""
echo "✅ DONE"
echo "NEXT:"
echo "  1) restart: npm run dev"
echo "  2) refund:"
echo "     curl -sS -X POST \"\$API/v1/purchases/\$PURCHASE_ID/refund\" -H \"content-type: application/json\" -H \"authorization: Bearer \$TOKEN\" -H \"x-organization-id: \$ORG_ID\" -d '{\"refundMethod\":\"card\",\"amount\":2000}' | jq"
