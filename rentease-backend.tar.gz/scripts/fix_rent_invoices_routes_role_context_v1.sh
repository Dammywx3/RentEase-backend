#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/src/routes/rent_invoices.ts"
BAK="$ROOT/scripts/.bak"
mkdir -p "$BAK"
ts="$(date +%Y%m%d_%H%M%S)"

cp "$FILE" "$BAK/rent_invoices.ts.bak.$ts"
echo "✅ backup -> scripts/.bak/rent_invoices.ts.bak.$ts"

cat > "$FILE" <<'TS'
import type { FastifyInstance } from "fastify";
import type { PoolClient } from "pg";
import { z } from "zod";
import {
  generateRentInvoiceForTenancy,
  getRentInvoices,
  payRentInvoice,
} from "../services/rent_invoices.service.js";
import {
  GenerateRentInvoiceBodySchema,
  ListRentInvoicesQuerySchema,
  PayRentInvoiceBodySchema,
} from "../schemas/rent_invoices.schema.js";

type AuthReq = {
  user?: { sub?: string; role?: string };
  jwtVerify?: () => Promise<void>;
  params?: any;
  body?: any;
  query?: any;
  headers?: any;
};

async function ensureAuth(app: FastifyInstance, req: any, reply: any) {
  try {
    if (typeof req?.jwtVerify === "function") {
      await req.jwtVerify();
      return null;
    }
    if (typeof (app as any).authenticate === "function") {
      await (app as any).authenticate(req, reply);
      return null;
    }
    return reply.code(500).send({
      ok: false,
      error: "JWT_NOT_CONFIGURED",
      message: "jwtVerify/app.authenticate not found. Ensure JWT plugin is registered.",
    });
  } catch {
    return reply.code(401).send({ ok: false, error: "UNAUTHORIZED", message: "Unauthorized" });
  }
}

function requireUserId(req: any) {
  const sub = req?.user?.sub;
  if (!sub) {
    const e: any = new Error("Missing authenticated user id (req.user.sub)");
    e.code = "USER_ID_MISSING";
    throw e;
  }
  return sub as string;
}

function getOrgIdFromHeaders(req: any) {
  const h = req?.headers ?? {};
  return (
    h["x-organization-id"] ||
    h["X-Organization-Id"] ||
    h["x-organization-id".toLowerCase()]
  );
}

async function applyDbContext(client: PoolClient, req: any) {
  const orgId = getOrgIdFromHeaders(req);
  const userId = req?.user?.sub || "";
  const role = req?.user?.role || "";

  if (!orgId) {
    const e: any = new Error("Missing x-organization-id header");
    e.code = "ORG_ID_MISSING";
    throw e;
  }

  const org = String(orgId);
  const uid = userId ? String(userId) : "";
  const r = role ? String(role) : "";

  // ---- ORG context (must match current_organization_uuid()) ----
  await client.query("SELECT set_config('request.header.x_organization_id', $1, true);", [org]);
  await client.query("SELECT set_config('request.jwt.claim.org', $1, true);", [org]);
  await client.query("SELECT set_config('request.jwt.claims.org', $1, true);", [org]);
  await client.query("SELECT set_config('request.jwt.claim.organization_id', $1, true);", [org]);
  await client.query("SELECT set_config('app.organization_id', $1, true);", [org]);

  // ---- USER context ----
  await client.query("SELECT set_config('request.jwt.claim.sub', $1, true);", [uid]);
  await client.query("SELECT set_config('request.user_id', $1, true);", [uid]);
  await client.query("SELECT set_config('app.user_id', $1, true);", [uid]);
  await client.query("SELECT set_config('rentease.user_id', $1, true);", [uid]);

  // ---- ROLE context (drives is_admin()) ----
  await client.query("SELECT set_config('request.user_role', $1, true);", [r]);
  await client.query("SELECT set_config('app.user_role', $1, true);", [r]);
  await client.query("SELECT set_config('rentease.user_role', $1, true);", [r]);
}

async function fetchDbRole(client: PoolClient, userId: string) {
  const roleRes = await client.query<{ role: string }>(
    "select role from public.users where id = $1::uuid limit 1;",
    [userId]
  );
  return roleRes.rows[0]?.role ?? null;
}

export async function rentInvoicesRoutes(app: FastifyInstance) {
  // Generate invoice for a tenancy
  app.post("/v1/tenancies/:id/rent-invoices/generate", async (req, reply) => {
    const authResp = await ensureAuth(app, req, reply);
    if (authResp) return authResp;

    try {
      const userId = requireUserId(req);
      const params = z.object({ id: z.string().uuid() }).parse((req as any).params);
      const body = GenerateRentInvoiceBodySchema.parse((req as any).body);

      const pgAny: any = (app as any).pg;
      if (!pgAny?.connect) {
        return reply.code(500).send({ ok: false, error: "PG_NOT_CONFIGURED", message: "Fastify pg plugin not found at app.pg" });
      }

      const client = (await pgAny.connect()) as PoolClient;
      try {
        // set role BEFORE applying db context (important for RLS)
        const dbRole = await fetchDbRole(client, userId);
        (req as any).user = (req as any).user ?? {};
        (req as any).user.role = dbRole ?? "";

        await applyDbContext(client, req);
        await client.query("BEGIN");

        const res = await generateRentInvoiceForTenancy(client, {
          tenancyId: params.id,
          periodStart: body.periodStart,
          periodEnd: body.periodEnd,
          dueDate: body.dueDate,
          subtotal: body.subtotal,
          lateFeeAmount: body.lateFeeAmount,
          currency: body.currency,
          status: body.status,
          notes: body.notes,
        });

        await client.query("COMMIT");
        return reply.send({ ok: true, reused: res.reused, data: res.row });
      } catch (err: any) {
        try { await client.query("ROLLBACK"); } catch {}
        return reply.code(500).send({ ok: false, error: err?.code ?? "INTERNAL_ERROR", message: err?.message ?? String(err) });
      } finally {
        client.release();
      }
    } catch (err: any) {
      return reply.code(400).send({ ok: false, error: err?.code ?? "BAD_REQUEST", message: err?.message ?? String(err) });
    }
  });

  // List invoices
  app.get("/v1/rent-invoices", async (req, reply) => {
    const authResp = await ensureAuth(app, req, reply);
    if (authResp) return authResp;

    try {
      const userId = requireUserId(req);
      const q = ListRentInvoicesQuerySchema.parse((req as any).query);

      const pgAny: any = (app as any).pg;
      if (!pgAny?.connect) {
        return reply.code(500).send({ ok: false, error: "PG_NOT_CONFIGURED", message: "Fastify pg plugin not found at app.pg" });
      }

      const client = (await pgAny.connect()) as PoolClient;
      try {
        const dbRole = await fetchDbRole(client, userId);
        (req as any).user = (req as any).user ?? {};
        (req as any).user.role = dbRole ?? "";

        await applyDbContext(client, req);

        const data = await getRentInvoices(client, {
          limit: q.limit,
          offset: q.offset,
          tenancyId: q.tenancyId,
          tenantId: q.tenantId,
          propertyId: q.propertyId,
          status: q.status,
        });

        return reply.send({ ok: true, data, paging: { limit: q.limit, offset: q.offset } });
      } catch (err: any) {
        return reply.code(500).send({ ok: false, error: err?.code ?? "INTERNAL_ERROR", message: err?.message ?? String(err) });
      } finally {
        client.release();
      }
    } catch (err: any) {
      return reply.code(400).send({ ok: false, error: err?.code ?? "BAD_REQUEST", message: err?.message ?? String(err) });
    }
  });

  // Pay invoice
  app.post("/v1/rent-invoices/:id/pay", async (req, reply) => {
    const authResp = await ensureAuth(app, req, reply);
    if (authResp) return authResp;

    const anyReq = req as unknown as AuthReq;
    const userId = anyReq.user?.sub;
    if (!userId) {
      return reply.code(401).send({ ok: false, error: "USER_ID_MISSING", message: "Missing authenticated user id (req.user.sub)" });
    }

    const pgAny: any = (app as any).pg;
    if (!pgAny?.connect) {
      return reply.code(500).send({ ok: false, error: "PG_NOT_CONFIGURED", message: "Fastify pg plugin not found at app.pg" });
    }

    const params = z.object({ id: z.string().uuid() }).parse((anyReq as any).params);
    const body = PayRentInvoiceBodySchema.parse((anyReq as any).body);

    const client = (await pgAny.connect()) as PoolClient;
    try {
      // fetch role first, set req.user.role, THEN apply context (critical)
      const dbRole = await fetchDbRole(client, userId);
      anyReq.user = anyReq.user ?? {};
      anyReq.user.role = dbRole ?? "";

      await applyDbContext(client, req);

      if (dbRole !== "admin") {
        return reply.code(403).send({ ok: false, error: "FORBIDDEN", message: "Admin only for now (policy requires admin or service role)." });
      }

      await client.query("BEGIN");

      const res = await payRentInvoice(client, {
        invoiceId: params.id,
        paymentMethod: body.paymentMethod,
        amount: body.amount,
      });

      await client.query("COMMIT");
      return reply.send({ ok: true, alreadyPaid: res.alreadyPaid, data: res.row });
    } catch (err: any) {
      try { await client.query("ROLLBACK"); } catch {}
      return reply.code(500).send({ ok: false, error: err?.code ?? "INTERNAL_ERROR", message: err?.message ?? String(err) });
    } finally {
      client.release();
    }
  });
}
TS

echo "✅ wrote $FILE"
echo "➡️ Restart server: npm run dev"
