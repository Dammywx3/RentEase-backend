import rawBody from "fastify-raw-body";
import type { FastifyInstance } from "fastify";

export async function rawBodyPlugin(app: FastifyInstance) {
  // Adds: request.rawBody (Buffer)
  await app.register(rawBody, {
    field: "rawBody",
    global: false,     // only for routes with config: { rawBody: true }
    encoding: false,   // keep Buffer for signature verification
    runFirst: true,
  });
}
