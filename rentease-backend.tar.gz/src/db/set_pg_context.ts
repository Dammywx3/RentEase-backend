// src/db/set_pg_context.ts
import type { PoolClient } from "pg";

export async function setPgContext(
  client: PoolClient,
  opts: { userId?: string | null; organizationId?: string | null }
) {
  const userId = opts.userId ? String(opts.userId) : "";
  const orgId = opts.organizationId ? String(opts.organizationId) : "";

  await client.query("select set_config('app.user_id', $1, true)", [userId]);
  await client.query("select set_config('app.organization_id', $1, true)", [orgId]);
}