// src/repos/tenancies.repo.ts
import type { PoolClient } from "pg";

export type TenancyStatus = "active" | "ended" | "terminated" | "pending_start";

export type TenancyRow = {
  id: string;

  tenant_id: string;
  property_id: string;
  listing_id: string | null;

  rent_amount: string;
  security_deposit: string | null;
  payment_cycle: string | null;

  start_date: string; // YYYY-MM-DD
  end_date: string | null; // YYYY-MM-DD or null
  next_due_date: string; // YYYY-MM-DD

  notice_period_days: number | null;
  status: TenancyStatus | null;

  termination_reason: string | null;
  late_fee_percentage: string | null;
  grace_period_days: number | null;

  created_at: string;
  updated_at: string;
  deleted_at: string | null;

  version: number | null;
};

export type InsertTenancyArgs = {
  tenant_id: string;
  property_id: string;
  listing_id?: string | null;

  rent_amount: number;
  security_deposit?: number | null;

  start_date: string; // YYYY-MM-DD
  next_due_date: string; // YYYY-MM-DD

  payment_cycle?: string | null;
  status?: TenancyStatus | null;

  termination_reason?: string | null;
};

// For INSERT ... RETURNING (no alias available)
const TENANCY_SELECT = `
  id,
  tenant_id,
  property_id,
  listing_id,
  rent_amount,
  security_deposit,
  payment_cycle,
  start_date::text    AS start_date,
  end_date::text      AS end_date,
  next_due_date::text AS next_due_date,
  notice_period_days,
  status,
  termination_reason,
  late_fee_percentage,
  grace_period_days,
  created_at,
  updated_at,
  deleted_at,
  version
`;

// For SELECT/UPDATE queries where we alias tenancies as "t"
const TENANCY_SELECT_T = `
  t.id,
  t.tenant_id,
  t.property_id,
  t.listing_id,
  t.rent_amount,
  t.security_deposit,
  t.payment_cycle,
  t.start_date::text    AS start_date,
  t.end_date::text      AS end_date,
  t.next_due_date::text AS next_due_date,
  t.notice_period_days,
  t.status,
  t.termination_reason,
  t.late_fee_percentage,
  t.grace_period_days,
  t.created_at,
  t.updated_at,
  t.deleted_at,
  t.version
`;

const OPEN_STATUSES: TenancyStatus[] = ["active", "pending_start"];

export async function findOpenTenancyByTenantProperty(
  client: PoolClient,
  tenantId: string,
  propertyId: string
): Promise<TenancyRow | null> {
  const { rows } = await client.query<TenancyRow>(
    `
    SELECT ${TENANCY_SELECT_T}
    FROM public.tenancies t
    WHERE t.tenant_id = $1
      AND t.property_id = $2
      AND t.deleted_at IS NULL
      AND t.status = ANY($3::tenancy_status[])
    ORDER BY t.created_at DESC
    LIMIT 1;
    `,
    [tenantId, propertyId, OPEN_STATUSES]
  );
  return rows[0] ?? null;
}

/**
 * Patch ONLY missing fields on an existing open tenancy.
 * - does not overwrite values already set
 * - bumps updated_at only if something changed
 * - uses FOR UPDATE to avoid racey read/modify/write
 */
export async function patchOpenTenancyMissingFields(
  client: PoolClient,
  tenancyId: string,
  patch: {
    listing_id?: string | null;
    security_deposit?: number | null;
    termination_reason?: string | null;
  }
): Promise<{ row: TenancyRow; patched: boolean }> {
  const { rows } = await client.query<TenancyRow & { patched: boolean }>(
    `
    WITH prev AS (
      SELECT
        t.id,
        t.listing_id,
        t.security_deposit,
        t.termination_reason,
        t.updated_at
      FROM public.tenancies t
      WHERE t.id = $1
      FOR UPDATE
    ),
    upd AS (
      UPDATE public.tenancies t
      SET
        listing_id = COALESCE(prev.listing_id, $2::uuid),
        security_deposit = COALESCE(prev.security_deposit, $3::numeric),
        termination_reason = COALESCE(prev.termination_reason, $4::text),
        updated_at = CASE
          WHEN
            (prev.listing_id IS NULL AND $2::uuid IS NOT NULL)
            OR (prev.security_deposit IS NULL AND $3::numeric IS NOT NULL)
            OR (prev.termination_reason IS NULL AND $4::text IS NOT NULL)
          THEN NOW()
          ELSE prev.updated_at
        END
      FROM prev
      WHERE t.id = prev.id
      RETURNING
        ${TENANCY_SELECT_T},
        (
          (prev.listing_id IS NULL AND $2::uuid IS NOT NULL)
          OR (prev.security_deposit IS NULL AND $3::numeric IS NOT NULL)
          OR (prev.termination_reason IS NULL AND $4::text IS NOT NULL)
        ) AS patched
    )
    SELECT * FROM upd;
    `,
    [
      tenancyId,
      patch.listing_id ?? null,
      patch.security_deposit ?? null,
      patch.termination_reason ?? null,
    ]
  );

  const row = rows[0]!;
  const patched = (row as any).patched === true;
  delete (row as any).patched;

  return { row, patched };
}

export async function insertTenancy(client: PoolClient, data: InsertTenancyArgs): Promise<TenancyRow> {
  const { rows } = await client.query<TenancyRow>(
    `
    INSERT INTO public.tenancies (
      tenant_id,
      property_id,
      listing_id,
      rent_amount,
      security_deposit,
      start_date,
      next_due_date,
      payment_cycle,
      status,
      termination_reason
    )
    VALUES (
      $1, $2, $3,
      $4::numeric,
      $5::numeric,
      $6::date,
      $7::date,
      COALESCE($8::payment_cycle, 'monthly'::payment_cycle),
      COALESCE($9::tenancy_status, 'pending_start'::tenancy_status),
      $10
    )
    RETURNING ${TENANCY_SELECT};
    `,
    [
      data.tenant_id,
      data.property_id,
      data.listing_id ?? null,
      data.rent_amount,
      data.security_deposit ?? null,
      data.start_date,
      data.next_due_date,
      data.payment_cycle ?? null,
      data.status ?? null,
      data.termination_reason ?? null,
    ]
  );

  return rows[0]!;
}

export async function createTenancyIdempotent(
  client: PoolClient,
  data: InsertTenancyArgs
): Promise<{ row: TenancyRow; reused: boolean; patched: boolean }> {
  const existing = await findOpenTenancyByTenantProperty(client, data.tenant_id, data.property_id);
  if (existing) {
    const patchedRes = await patchOpenTenancyMissingFields(client, existing.id, {
      listing_id: data.listing_id ?? null,
      security_deposit: data.security_deposit ?? null,
      termination_reason: data.termination_reason ?? null,
    });
    return { row: patchedRes.row, reused: true, patched: patchedRes.patched };
  }

  try {
    const row = await insertTenancy(client, data);
    return { row, reused: false, patched: false };
  } catch (err: any) {
    if (err?.code === "23505") {
      const again = await findOpenTenancyByTenantProperty(client, data.tenant_id, data.property_id);
      if (again) {
        const patchedRes = await patchOpenTenancyMissingFields(client, again.id, {
          listing_id: data.listing_id ?? null,
          security_deposit: data.security_deposit ?? null,
          termination_reason: data.termination_reason ?? null,
        });
        return { row: patchedRes.row, reused: true, patched: patchedRes.patched };
      }
    }
    throw err;
  }
}

export async function listTenancies(
  client: PoolClient,
  args: {
    limit: number;
    offset: number;
    tenant_id?: string;
    property_id?: string;
    listing_id?: string;
    status?: TenancyStatus;
  }
): Promise<TenancyRow[]> {
  const where: string[] = ["t.deleted_at IS NULL"];
  const params: any[] = [];
  let i = 1;

  if (args.tenant_id) {
    where.push(`t.tenant_id = $${i++}`);
    params.push(args.tenant_id);
  }
  if (args.property_id) {
    where.push(`t.property_id = $${i++}`);
    params.push(args.property_id);
  }
  if (args.listing_id) {
    where.push(`t.listing_id = $${i++}`);
    params.push(args.listing_id);
  }
  if (args.status) {
    where.push(`t.status = $${i++}::tenancy_status`);
    params.push(args.status);
  }

  params.push(args.limit);
  const limitIdx = i++;
  params.push(args.offset);
  const offsetIdx = i++;

  const { rows } = await client.query<TenancyRow>(
    `
    SELECT ${TENANCY_SELECT_T}
    FROM public.tenancies t
    WHERE ${where.join(" AND ")}
    ORDER BY t.created_at DESC
    LIMIT $${limitIdx} OFFSET $${offsetIdx};
    `,
    params
  );

  return rows;
}

/** END TENANCY (PATCH /v1/tenancies/:id/end) */
export async function endTenancyById(
  client: PoolClient,
  id: string,
  patch: {
    status: "ended" | "terminated";
    end_date?: string | null;
    termination_reason?: string | null;
  }
): Promise<{ row: TenancyRow; changed: boolean }> {
  const { rows } = await client.query<TenancyRow & { changed: boolean }>(
    `
    WITH prev AS (
      SELECT
        t.id,
        t.status,
        t.end_date,
        t.termination_reason
      FROM public.tenancies t
      WHERE t.id = $1
      FOR UPDATE
    ),
    upd AS (
      UPDATE public.tenancies t
      SET
        status = $2::tenancy_status,
        end_date = COALESCE($3::date, CURRENT_DATE),
        termination_reason = COALESCE($4::text, t.termination_reason),
        updated_at = CASE
          WHEN
            (t.status IS DISTINCT FROM $2::tenancy_status)
            OR (t.end_date IS DISTINCT FROM COALESCE($3::date, CURRENT_DATE))
            OR (t.termination_reason IS DISTINCT FROM COALESCE($4::text, t.termination_reason))
          THEN NOW()
          ELSE t.updated_at
        END
      FROM prev
      WHERE t.id = prev.id
      RETURNING
        ${TENANCY_SELECT_T},
        (
          (prev.status IS DISTINCT FROM $2::tenancy_status)
          OR (prev.end_date IS DISTINCT FROM COALESCE($3::date, CURRENT_DATE))
          OR (prev.termination_reason IS DISTINCT FROM COALESCE($4::text, prev.termination_reason))
        ) AS changed
    )
    SELECT * FROM upd;
    `,
    [id, patch.status, patch.end_date ?? null, patch.termination_reason ?? null]
  );

  const row = rows[0]!;
  const changed = (row as any).changed === true;
  delete (row as any).changed;

  return { row, changed };
}

/** START TENANCY (PATCH /v1/tenancies/:id/start) */
export async function startTenancyById(
  client: PoolClient,
  id: string,
  patch: { start_date?: string | null }
): Promise<{ row: TenancyRow; changed: boolean }> {
  const { rows } = await client.query<TenancyRow & { changed: boolean }>(
    `
    WITH prev AS (
      SELECT
        t.id,
        t.status,
        t.start_date
      FROM public.tenancies t
      WHERE t.id = $1
      FOR UPDATE
    ),
    upd AS (
      UPDATE public.tenancies t
      SET
        start_date = COALESCE($2::date, t.start_date),
        status = CASE
          WHEN t.status = 'pending_start'::tenancy_status THEN 'active'::tenancy_status
          ELSE t.status
        END,
        updated_at = CASE
          WHEN
            (t.start_date IS DISTINCT FROM COALESCE($2::date, t.start_date))
            OR (t.status = 'pending_start'::tenancy_status)
          THEN NOW()
          ELSE t.updated_at
        END
      FROM prev
      WHERE t.id = prev.id
      RETURNING
        ${TENANCY_SELECT_T},
        (
          (prev.start_date IS DISTINCT FROM COALESCE($2::date, prev.start_date))
          OR (prev.status = 'pending_start'::tenancy_status)
        ) AS changed
    )
    SELECT * FROM upd;
    `,
    [id, patch.start_date ?? null]
  );

  const row = rows[0]!;
  const changed = (row as any).changed === true;
  delete (row as any).changed;

  return { row, changed };
}