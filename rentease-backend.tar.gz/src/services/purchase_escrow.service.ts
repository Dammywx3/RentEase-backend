// src/services/purchase_escrow.service.ts
import type { PoolClient } from "pg";

type HoldEscrowInput = {
  organizationId: string;
  purchaseId: string;
  actorUserId: string;
  note?: string | null;
  amount?: number; // optional override, else uses deposit_amount or agreed_price
};

type ReleaseEscrowInput = {
  organizationId: string;
  purchaseId: string;
  actorUserId: string;
  note?: string | null;
  platformFeeAmount?: number; // optional
};

async function getOrCreateUserWallet(
  client: PoolClient,
  organizationId: string,
  userId: string,
  currency: string
): Promise<string> {
  const found = await client.query(
    `
    select id::text as id
    from public.wallet_accounts
    where organization_id = $1::uuid
      and user_id = $2::uuid
      and currency = $3
      and is_platform_wallet = false
    limit 1;
    `,
    [organizationId, userId, currency]
  );

  if (found.rows[0]?.id) return found.rows[0].id;

  const created = await client.query(
    `
    insert into public.wallet_accounts (id, organization_id, user_id, currency, is_platform_wallet)
    values (rentease_uuid(), $1::uuid, $2::uuid, $3, false)
    returning id::text as id;
    `,
    [organizationId, userId, currency]
  );

  return created.rows[0].id;
}

async function getOrCreateEscrowWallet(client: PoolClient, organizationId: string, currency: string) {
  const { rows } = await client.query(
    `select public.get_or_create_org_escrow_wallet($1::uuid, $2)::text as id;`,
    [organizationId, currency]
  );
  return rows[0].id as string;
}

async function getOrCreatePlatformFeeWallet(client: PoolClient, organizationId: string, currency: string) {
  // Try find a platform wallet that is NOT the escrow wallet
  const { rows } = await client.query(
    `
    select wa.id::text as id
    from public.wallet_accounts wa
    where wa.organization_id = $1::uuid
      and wa.currency = $2
      and wa.is_platform_wallet = true
      and wa.id not in (
        select ewa.wallet_account_id
        from public.escrow_wallet_accounts ewa
        where ewa.organization_id = $1::uuid
          and ewa.currency = $2
      )
    order by wa.created_at asc
    limit 1;
    `,
    [organizationId, currency]
  );

  if (rows[0]?.id) return rows[0].id as string;

  const created = await client.query(
    `
    insert into public.wallet_accounts (id, organization_id, user_id, currency, is_platform_wallet)
    values (rentease_uuid(), $1::uuid, null, $2, true)
    returning id::text as id;
    `,
    [organizationId, currency]
  );

  return created.rows[0].id as string;
}

export async function holdEscrowForPurchase(client: PoolClient, input: HoldEscrowInput) {
  const { organizationId, purchaseId, note, amount } = input;

  await client.query("begin");
  try {
    // Lock purchase row to avoid double hold
    const p = await client.query(
      `
      select
        id::text as id,
        organization_id::text as organization_id,
        buyer_id::text as buyer_id,
        seller_id::text as seller_id,
        currency,
        status::text as status,
        agreed_price::numeric as agreed_price,
        deposit_amount::numeric as deposit_amount,
        escrow_wallet_account_id::text as escrow_wallet_account_id,
        escrow_held_amount::numeric as escrow_held_amount,
        escrow_released_amount::numeric as escrow_released_amount
      from public.property_purchases
      where id = $1::uuid
        and organization_id = $2::uuid
        and deleted_at is null
      for update;
      `,
      [purchaseId, organizationId]
    );

    const purchase = p.rows[0];
    if (!purchase) {
      throw Object.assign(new Error("Purchase not found"), { code: "NOT_FOUND" });
    }

    // Already held? Idempotent: do nothing
    if (Number(purchase.escrow_held_amount || 0) > 0) {
      await client.query("commit");
      return { ok: true, alreadyHeld: true, purchaseId };
    }

    const currency = String(purchase.currency || "USD");
    const holdAmount =
      typeof amount === "number" && amount > 0
        ? amount
        : Number(purchase.deposit_amount ?? 0) > 0
          ? Number(purchase.deposit_amount)
          : Number(purchase.agreed_price);

    if (!Number.isFinite(holdAmount) || holdAmount <= 0) {
      throw Object.assign(new Error("Invalid escrow hold amount"), { code: "INVALID_AMOUNT" });
    }

    const buyerId = purchase.buyer_id as string;
    const buyerWalletId = await getOrCreateUserWallet(client, organizationId, buyerId, currency);
    const escrowWalletId = await getOrCreateEscrowWallet(client, organizationId, currency);

    // Ledger entries (unique constraints prevent duplicates per wallet/txn_type)
    await client.query(
      `
      insert into public.wallet_transactions (
        id, organization_id, wallet_account_id, txn_type, reference_type, reference_id,
        amount, currency, note
      ) values (
        rentease_uuid(), $1::uuid, $2::uuid, 'debit_buyer'::wallet_transaction_type,
        'purchase', $3::uuid, $4::numeric, $5, $6
      )
      on conflict do nothing;
      `,
      [organizationId, buyerWalletId, purchaseId, holdAmount, currency, note ?? null]
    );

    await client.query(
      `
      insert into public.wallet_transactions (
        id, organization_id, wallet_account_id, txn_type, reference_type, reference_id,
        amount, currency, note
      ) values (
        rentease_uuid(), $1::uuid, $2::uuid, 'credit_escrow'::wallet_transaction_type,
        'purchase', $3::uuid, $4::numeric, $5, $6
      )
      on conflict do nothing;
      `,
      [organizationId, escrowWalletId, purchaseId, holdAmount, currency, note ?? null]
    );

    // Save escrow state on purchase
    const upd = await client.query(
      `
      update public.property_purchases
      set
        escrow_wallet_account_id = $3::uuid,
        escrow_held_amount = $4::numeric,
        updated_at = now()
      where id = $1::uuid
        and organization_id = $2::uuid
      returning id::text as id, escrow_wallet_account_id::text as escrow_wallet_account_id,
                escrow_held_amount::text as escrow_held_amount;
      `,
      [purchaseId, organizationId, escrowWalletId, holdAmount]
    );

    await client.query("commit");
    return { ok: true, held: true, purchase: upd.rows[0] };
  } catch (e) {
    await client.query("rollback");
    throw e;
  }
}

export async function releaseEscrowForPurchase(client: PoolClient, input: ReleaseEscrowInput) {
  const { organizationId, purchaseId, note, platformFeeAmount } = input;

  await client.query("begin");
  try {
    const p = await client.query(
      `
      select
        id::text as id,
        organization_id::text as organization_id,
        buyer_id::text as buyer_id,
        seller_id::text as seller_id,
        currency,
        escrow_wallet_account_id::text as escrow_wallet_account_id,
        escrow_held_amount::numeric as escrow_held_amount,
        escrow_released_amount::numeric as escrow_released_amount
      from public.property_purchases
      where id = $1::uuid
        and organization_id = $2::uuid
        and deleted_at is null
      for update;
      `,
      [purchaseId, organizationId]
    );

    const purchase = p.rows[0];
    if (!purchase) throw Object.assign(new Error("Purchase not found"), { code: "NOT_FOUND" });

    const held = Number(purchase.escrow_held_amount || 0);
    const released = Number(purchase.escrow_released_amount || 0);
    const remaining = held - released;

    if (remaining <= 0) {
      await client.query("commit");
      return { ok: true, alreadyReleased: true, purchaseId };
    }

    const currency = String(purchase.currency || "USD");
    const escrowWalletId = purchase.escrow_wallet_account_id || (await getOrCreateEscrowWallet(client, organizationId, currency));
    const sellerId = purchase.seller_id as string;
    const sellerWalletId = await getOrCreateUserWallet(client, organizationId, sellerId, currency);

    const fee = typeof platformFeeAmount === "number" && platformFeeAmount > 0 ? platformFeeAmount : 0;
    if (fee < 0 || fee > remaining) {
      throw Object.assign(new Error("Invalid platform fee amount"), { code: "INVALID_FEE" });
    }

    const sellerAmount = remaining - fee;

    // Debit escrow
    await client.query(
      `
      insert into public.wallet_transactions (
        id, organization_id, wallet_account_id, txn_type, reference_type, reference_id,
        amount, currency, note
      ) values (
        rentease_uuid(), $1::uuid, $2::uuid, 'debit_escrow'::wallet_transaction_type,
        'purchase', $3::uuid, $4::numeric, $5, $6
      )
      on conflict do nothing;
      `,
      [organizationId, escrowWalletId, purchaseId, remaining, currency, note ?? null]
    );

    // Credit seller
    await client.query(
      `
      insert into public.wallet_transactions (
        id, organization_id, wallet_account_id, txn_type, reference_type, reference_id,
        amount, currency, note
      ) values (
        rentease_uuid(), $1::uuid, $2::uuid, 'credit_seller'::wallet_transaction_type,
        'purchase', $3::uuid, $4::numeric, $5, $6
      )
      on conflict do nothing;
      `,
      [organizationId, sellerWalletId, purchaseId, sellerAmount, currency, note ?? null]
    );

    // Optional platform fee
    if (fee > 0) {
      const platformWalletId = await getOrCreatePlatformFeeWallet(client, organizationId, currency);

      await client.query(
        `
        insert into public.wallet_transactions (
          id, organization_id, wallet_account_id, txn_type, reference_type, reference_id,
          amount, currency, note
        ) values (
          rentease_uuid(), $1::uuid, $2::uuid, 'credit_platform_fee'::wallet_transaction_type,
          'purchase', $3::uuid, $4::numeric, $5, $6
        )
        on conflict do nothing;
        `,
        [organizationId, platformWalletId, purchaseId, fee, currency, note ?? null]
      );
    }

    const upd = await client.query(
      `
      update public.property_purchases
      set
        escrow_released_amount = escrow_released_amount + $3::numeric,
        escrow_released_at = now(),
        updated_at = now()
      where id = $1::uuid
        and organization_id = $2::uuid
      returning id::text as id, escrow_released_amount::text as escrow_released_amount, escrow_released_at::text as escrow_released_at;
      `,
      [purchaseId, organizationId, remaining]
    );

    await client.query("commit");
    return { ok: true, released: true, purchase: upd.rows[0] };
  } catch (e) {
    await client.query("rollback");
    throw e;
  }
}