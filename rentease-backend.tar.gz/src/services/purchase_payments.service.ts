import type { PoolClient } from "pg";
import { computePlatformFeeSplit } from "../config/fees.config.js";
import { creditPayee, creditPlatformFee } from "./ledger.service.js";

export type PurchasePaymentMethod = "card" | "bank_transfer" | "wallet";

export type PropertyPurchaseRow = {
  id: string;
  organization_id: string;
  property_id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  agreed_price: string;
  currency: string;
  status: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
};

const PURCHASE_SELECT = `
  id,
  organization_id,
  property_id,
  listing_id,
  buyer_id,
  seller_id,
  agreed_price::text AS agreed_price,
  currency,
  status::text AS status,
  created_at::text AS created_at,
  updated_at::text AS updated_at,
  deleted_at::text AS deleted_at,
  payment_status::text AS payment_status,
  paid_at::text AS paid_at,
  paid_amount::text AS paid_amount,
  last_payment_id::text AS last_payment_id
`;

/** Load purchase row (strict org + not deleted) */
export async function getPropertyPurchase(
  client: PoolClient,
  args: { organizationId: string; purchaseId: string }
): Promise<PropertyPurchaseRow> {
  const { rows } = await client.query<PropertyPurchaseRow>(
    `
    SELECT ${PURCHASE_SELECT}
    FROM public.property_purchases
    WHERE id = $1::uuid
      AND organization_id = $2::uuid
      AND deleted_at IS NULL
    LIMIT 1;
    `,
    [args.purchaseId, args.organizationId]
  );

  const row = rows[0];
  if (!row) {
    const e: any = new Error("Purchase not found");
    e.code = "PURCHASE_NOT_FOUND";
    throw e;
  }
  return row;
}

/**
 * PAY purchase
 * Idempotent-ish:
 *  - If already has BOTH txns (platform fee + payee) for this purchase reference, we return alreadyPaid=true.
 *  - Also uses ON CONFLICT DO NOTHING in ledger.service insert (assuming you keep that).
 */
export async function payPropertyPurchase(
  client: PoolClient,
  args: {
    organizationId: string;
    purchaseId: string;
    paymentMethod: PurchasePaymentMethod;
    amount?: number | null; // defaults to agreed_price
  }
): Promise<{
  purchase: PropertyPurchaseRow;
  alreadyPaid: boolean;
  platformFee: number;
  sellerNet: number;
}> {
  const purchase = await getPropertyPurchase(client, {
    organizationId: args.organizationId,
    purchaseId: args.purchaseId,
  });

  // Check if BOTH ledger txns already exist for this purchase (reference_type='purchase')
  const chk = await client.query<{ txn_type: string; cnt: string }>(
    `
    SELECT wt.txn_type::text AS txn_type, count(*)::text AS cnt
    FROM public.wallet_transactions wt
    WHERE wt.organization_id = $1::uuid
      AND wt.reference_type = 'purchase'
      AND wt.reference_id = $2::uuid
      AND wt.txn_type IN ('credit_payee'::wallet_transaction_type, 'credit_platform_fee'::wallet_transaction_type)
    GROUP BY wt.txn_type
    `,
    [args.organizationId, purchase.id]
  );

  const hasPayee = chk.rows.some((r) => r.txn_type === "credit_payee" && Number(r.cnt) > 0);
  const hasFee = chk.rows.some((r) => r.txn_type === "credit_platform_fee" && Number(r.cnt) > 0);

  if (hasPayee && hasFee) {
    const agreed = Number(purchase.agreed_price);
    const split = computePlatformFeeSplit({
      paymentKind: "buy",
      amount: agreed,
      currency: (purchase.currency ?? "USD") || "USD",
    });

      // ------------------------------------------------------------
      // Milestones: mark purchase as paid (without changing lifecycle enum)
      // - payment_status='paid'
      // - paid_at set once
      // - paid_amount defaults to agreed_price
      // - last_payment_id set from latest purchase-payment link (if exists)
      // ------------------------------------------------------------
      const lastPay = await client.query<{ payment_id: string | null }>(
        `
        SELECT ppp.payment_id::text AS payment_id
        FROM public.property_purchase_payments ppp
        WHERE ppp.organization_id = $1::uuid
          AND ppp.purchase_id = $2::uuid
        ORDER BY ppp.created_at DESC
        LIMIT 1;
        `,
        [args.organizationId, purchase.id]
      );

      const lastPaymentId = lastPay.rows?.[0]?.payment_id ?? null;

      await client.query(
        `
        UPDATE public.property_purchases
        SET
          payment_status = 'paid'::purchase_payment_status,
          paid_at = COALESCE(paid_at, NOW()),
          paid_amount = COALESCE(paid_amount, agreed_price),
          last_payment_id = COALESCE(last_payment_id, $1::uuid),
          updated_at = NOW()
        WHERE id = $2::uuid
          AND organization_id = $3::uuid
          AND deleted_at IS NULL;
        `,
        [lastPaymentId, purchase.id, args.organizationId]
      );
    const refreshed = await getPropertyPurchase(client, {

      organizationId: args.organizationId,

      purchaseId: purchase.id,

    });


    return { purchase: refreshed, alreadyPaid: true, platformFee: 0, sellerNet: 0 };
}

  const agreed = Number(purchase.agreed_price);
  const amount = typeof args.amount === "number" ? args.amount : agreed;

  if (Number(amount) !== Number(agreed)) {
    const e: any = new Error(`Payment.amount (${amount}) must equal agreed_price (${purchase.agreed_price})`);
    e.code = "AMOUNT_MISMATCH";
    throw e;
  }

  const currency = (purchase.currency ?? "USD") || "USD";

  const split = computePlatformFeeSplit({
    paymentKind: "buy",
    amount,
    currency,
  });

  // 1) credit platform fee
  await creditPlatformFee(client, {
    organizationId: args.organizationId,
    referenceType: "purchase",
    referenceId: purchase.id,
    amount: split.platformFee,
    currency,
    note: `2.5% platform fee for purchase ${purchase.id}`,
  });

  // 2) credit seller net
  await creditPayee(client, {
    organizationId: args.organizationId,
    payeeUserId: purchase.seller_id,
    referenceType: "purchase",
    referenceId: purchase.id,
    amount: split.payeeNet,
    currency,
    note: `Purchase payout (net) for purchase ${purchase.id}`,
  });

  // 3) Update purchase payment milestone fields (does NOT change lifecycle status enum)
  // payment_status tracks money state; status tracks workflow (under_contract, escrow_opened, closing_scheduled, etc.)
  await client.query(
    `
    UPDATE public.property_purchases pp
    SET
      paid_at = COALESCE(pp.paid_at, NOW()),
      paid_amount = COALESCE(pp.paid_amount, 0) + $1::numeric,
      payment_status = CASE
        WHEN (COALESCE(pp.paid_amount, 0) + $1::numeric) >= pp.agreed_price THEN 'paid'::purchase_payment_status
        WHEN (COALESCE(pp.paid_amount, 0) + $1::numeric) > 0 THEN 'partially_paid'::purchase_payment_status
        ELSE pp.payment_status
      END,
      last_payment_id = COALESCE(
        (
          SELECT ppp.payment_id
          FROM public.property_purchase_payments ppp
          WHERE ppp.purchase_id = pp.id
          ORDER BY ppp.created_at DESC
          LIMIT 1
        ),
        pp.last_payment_id
      ),
      updated_at = NOW()
    WHERE pp.id = $2::uuid
      AND pp.organization_id = $3::uuid
      AND pp.deleted_at IS NULL;
    `,
    [amount, purchase.id, args.organizationId]
  );


  // 3) Update purchase payment milestones (no lifecycle enum change)
  await client.query(
    `
    UPDATE public.property_purchases
    SET
      payment_status = 'paid'::purchase_payment_status,
      paid_at = COALESCE(paid_at, NOW()),
      paid_amount = $1::numeric,
      updated_at = NOW()
    WHERE id = $2::uuid
      AND organization_id = $3::uuid
      AND deleted_at IS NULL;
    `,
    [amount, purchase.id, args.organizationId]
  );


  const updated = await getPropertyPurchase(client, {
    organizationId: args.organizationId,
    purchaseId: purchase.id,
  });

  return { purchase: updated, alreadyPaid: false, platformFee: split.platformFee, sellerNet: split.payeeNet };
}
