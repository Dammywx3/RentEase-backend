import type { PoolClient } from "pg";
import { computePlatformFeeSplit } from "../config/fees.config.js";

export type RefundMethod = "card" | "bank_transfer" | "wallet";

export type PropertyPurchaseRow = {
  id: string;
  organization_id: string;
  property_id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  agreed_price: string;
  currency: string;
  status: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;

  payment_status: string;
  paid_at: string | null;
  paid_amount: string | null;
  last_payment_id: string | null;

  refunded_at: string | null;
  refunded_amount: string | null;

  refund_method: string | null;
  refunded_reason: string | null;
  refunded_by: string | null;
  refund_payment_id: string | null;
};

const PURCHASE_SELECT = `
  pp.id,
  pp.organization_id,
  pp.property_id,
  pp.listing_id,
  pp.buyer_id,
  pp.seller_id,
  pp.agreed_price::text AS agreed_price,
  pp.currency,
  pp.status::text AS status,
  pp.created_at::text AS created_at,
  pp.updated_at::text AS updated_at,
  pp.deleted_at::text AS deleted_at,

  pp.payment_status::text AS payment_status,
  pp.paid_at::text AS paid_at,
  pp.paid_amount::text AS paid_amount,
  pp.last_payment_id::text AS last_payment_id,

  pp.refunded_at::text AS refunded_at,
  pp.refunded_amount::text AS refunded_amount,

  pp.refund_method::text AS refund_method,
  pp.refunded_reason::text AS refunded_reason,
  pp.refunded_by::text AS refunded_by,
  pp.refund_payment_id::text AS refund_payment_id
`;

async function getPurchase(
  client: PoolClient,
  args: { organizationId: string; purchaseId: string }
): Promise<PropertyPurchaseRow> {
  const { rows } = await client.query<PropertyPurchaseRow>(
    `
    SELECT ${PURCHASE_SELECT}
    FROM public.property_purchases pp
    WHERE pp.id = $1::uuid
      AND pp.organization_id = $2::uuid
      AND pp.deleted_at IS NULL
    LIMIT 1;
    `,
    [args.purchaseId, args.organizationId]
  );

  const row = rows[0];
  if (!row) {
    const e: any = new Error("Purchase not found");
    e.code = "PURCHASE_NOT_FOUND";
    throw e;
  }
  return row;
}

async function getPlatformWalletAccountId(client: PoolClient, organizationId: string): Promise<string> {
  const { rows } = await client.query<{ id: string }>(
    `
    SELECT id::text AS id
    FROM public.wallet_accounts
    WHERE organization_id = $1::uuid
      AND is_platform_wallet = true
    LIMIT 1;
    `,
    [organizationId]
  );

  const id = rows[0]?.id;
  if (!id) {
    const e: any = new Error("Platform wallet not found");
    e.code = "PLATFORM_WALLET_NOT_FOUND";
    throw e;
  }
  return id;
}

async function getUserWalletAccountId(client: PoolClient, organizationId: string, userId: string): Promise<string> {
  const { rows } = await client.query<{ id: string }>(
    `
    SELECT id::text AS id
    FROM public.wallet_accounts
    WHERE organization_id = $1::uuid
      AND user_id = $2::uuid
      AND is_platform_wallet = false
    LIMIT 1;
    `,
    [organizationId, userId]
  );

  const id = rows[0]?.id;
  if (!id) {
    const e: any = new Error("User wallet not found");
    e.code = "USER_WALLET_NOT_FOUND";
    throw e;
  }
  return id;
}

async function hasRefundDebits(client: PoolClient, organizationId: string, purchaseId: string) {
  const { rows } = await client.query<{ txn_type: string; cnt: string }>(
    `
    SELECT wt.txn_type::text AS txn_type, count(*)::text AS cnt
    FROM public.wallet_transactions wt
    WHERE wt.organization_id = $1::uuid
      AND wt.reference_type = 'purchase'
      AND wt.reference_id = $2::uuid
      AND wt.txn_type IN (
        'debit_payee'::wallet_transaction_type,
        'debit_platform_fee'::wallet_transaction_type
      )
    GROUP BY wt.txn_type;
    `,
    [organizationId, purchaseId]
  );

  const hasPayee = rows.some((r) => r.txn_type === "debit_payee" && Number(r.cnt) > 0);
  const hasFee = rows.some((r) => r.txn_type === "debit_platform_fee" && Number(r.cnt) > 0);
  return { hasPayee, hasFee };
}

async function upsertRefundMilestones(
  client: PoolClient,
  args: {
    organizationId: string;
    purchaseId: string;
    amount: number;
    lastPaymentId: string | null;

    refundMethod?: string | null;
    reason?: string | null;
    refundedBy?: string | null;
    refundPaymentId?: string | null;
  }
) {
  await client.query(
    `
    UPDATE public.property_purchases
    SET
      payment_status = 'refunded'::purchase_payment_status,
      refunded_at = COALESCE(refunded_at, NOW()),
      refunded_amount = CASE
        WHEN $1::numeric = 0 THEN refunded_amount
        ELSE COALESCE(refunded_amount, 0) + $1::numeric
      END,

      -- audit fields (fill if empty / or fix placeholder reason like "card")
      refund_method = COALESCE(refund_method, $2::text),

      refunded_reason = CASE
        WHEN refunded_reason IS NULL THEN $3::text
        WHEN refunded_reason IN ('card','bank_transfer','wallet')
             AND $3::text IS NOT NULL
             AND $3::text NOT IN ('card','bank_transfer','wallet') THEN $3::text
        ELSE refunded_reason
      END,

      refunded_by = COALESCE(refunded_by, $4::uuid),
      refund_payment_id = COALESCE(refund_payment_id, $5::uuid),

      updated_at = NOW()
    WHERE id = $6::uuid
      AND organization_id = $7::uuid
      AND deleted_at IS NULL;
    `,
    [
      args.amount,
      args.refundMethod ?? null,
      args.reason ?? null,
      args.refundedBy ?? null,
      args.refundPaymentId ?? null,
      args.purchaseId,
      args.organizationId,
    ]
  );
}

async function insertDebitTxn(
  client: PoolClient,
  args: {
    organizationId: string;
    walletAccountId: string;
    txnType: "debit_platform_fee" | "debit_payee";
    amount: number;
    currency: string;
    purchaseId: string;
    note: string;
  }
) {
  const { rows } = await client.query<{ exists: boolean }>(
    `
    SELECT EXISTS(
      SELECT 1
      FROM public.wallet_transactions wt
      WHERE wt.organization_id = $1::uuid
        AND wt.wallet_account_id = $2::uuid
        AND wt.reference_type = 'purchase'
        AND wt.reference_id = $3::uuid
        AND wt.txn_type = $4::wallet_transaction_type
    ) AS exists;
    `,
    [args.organizationId, args.walletAccountId, args.purchaseId, args.txnType]
  );

  if (rows?.[0]?.exists) return;

  await client.query(
    `
    INSERT INTO public.wallet_transactions (
      organization_id,
      wallet_account_id,
      txn_type,
      amount,
      currency,
      reference_type,
      reference_id,
      note,
      created_at
    )
    VALUES (
      $1::uuid,
      $2::uuid,
      $3::wallet_transaction_type,
      $4::numeric,
      $5,
      'purchase',
      $6::uuid,
      $7,
      NOW()
    );
    `,
    [
      args.organizationId,
      args.walletAccountId,
      args.txnType,
      args.amount,
      args.currency,
      args.purchaseId,
      args.note,
    ]
  );
}

export async function refundPropertyPurchase(
  client: PoolClient,
  args: {
    organizationId: string;
    purchaseId: string;
    amount?: number | null;
    reason?: string | null;
    refundMethod?: RefundMethod;
    refundPaymentId?: string | null;
    refundedBy?: string | null;
  }
): Promise<{
  purchase: PropertyPurchaseRow;
  alreadyRefunded: boolean;
  platformFeeReversed: number;
  sellerReversed: number;
}> {
  const purchase = await getPurchase(client, {
    organizationId: args.organizationId,
    purchaseId: args.purchaseId,
  });

  // ✅ Idempotent: already refunded, but still fill audit fields
  if (purchase.payment_status === "refunded" || purchase.refunded_at) {
    await upsertRefundMilestones(client, {
      organizationId: args.organizationId,
      purchaseId: purchase.id,
      lastPaymentId: purchase.last_payment_id ?? null,
      amount: 0,
      refundMethod: args.refundMethod ?? null,
      reason: args.reason ?? null,
      refundPaymentId: args.refundPaymentId ?? null,
      refundedBy: args.refundedBy ?? null,
    });

    const updated = await getPurchase(client, { organizationId: args.organizationId, purchaseId: purchase.id });
    return { purchase: updated, alreadyRefunded: true, platformFeeReversed: 0, sellerReversed: 0 };
  }

  // Must be paid before refund
  if (purchase.payment_status !== "paid") {
    const e: any = new Error(`Purchase not refundable because payment_status=${purchase.payment_status}`);
    e.code = "NOT_PAID";
    throw e;
  }

  const agreed = Number(purchase.agreed_price);
  const paidAmount = purchase.paid_amount ? Number(purchase.paid_amount) : agreed;
  const amount = typeof args.amount === "number" ? args.amount : paidAmount;

  if (Number(amount) !== Number(paidAmount)) {
    const e: any = new Error(`Refund.amount (${amount}) must equal paid_amount (${paidAmount})`);
    e.code = "AMOUNT_MISMATCH";
    throw e;
  }

  const currency = (purchase.currency ?? "USD") || "USD";

  // idempotent by ledger txns too
  const debits = await hasRefundDebits(client, args.organizationId, purchase.id);
  if (debits.hasPayee && debits.hasFee) {
    await upsertRefundMilestones(client, {
      organizationId: args.organizationId,
      purchaseId: purchase.id,
      lastPaymentId: purchase.last_payment_id ?? null,
      amount: 0,
      refundMethod: args.refundMethod ?? null,
      reason: args.reason ?? null,
      refundPaymentId: args.refundPaymentId ?? null,
      refundedBy: args.refundedBy ?? null,
    });

    const updated = await getPurchase(client, { organizationId: args.organizationId, purchaseId: purchase.id });
    return { purchase: updated, alreadyRefunded: true, platformFeeReversed: 0, sellerReversed: 0 };
  }

  const split = computePlatformFeeSplit({
    paymentKind: "buy",
    amount,
    currency,
  });

  const platformWalletId = await getPlatformWalletAccountId(client, args.organizationId);
  const sellerWalletId = await getUserWalletAccountId(client, args.organizationId, purchase.seller_id);

  await insertDebitTxn(client, {
    organizationId: args.organizationId,
    walletAccountId: platformWalletId,
    txnType: "debit_platform_fee",
    amount: split.platformFee,
    currency,
    purchaseId: purchase.id,
    note: `Refund reversal: platform fee for purchase ${purchase.id}${args.reason ? ` (${args.reason})` : ""}`,
  });

  await insertDebitTxn(client, {
    organizationId: args.organizationId,
    walletAccountId: sellerWalletId,
    txnType: "debit_payee",
    amount: split.payeeNet,
    currency,
    purchaseId: purchase.id,
    note: `Refund reversal: seller payout for purchase ${purchase.id}${args.reason ? ` (${args.reason})` : ""}`,
  });

  await upsertRefundMilestones(client, {
    organizationId: args.organizationId,
    purchaseId: purchase.id,
    lastPaymentId: purchase.last_payment_id ?? null,
    amount,
    refundMethod: args.refundMethod ?? null,
    reason: args.reason ?? null,
    refundPaymentId: args.refundPaymentId ?? null,
    refundedBy: args.refundedBy ?? null,
  });

  const updated = await getPurchase(client, {
    organizationId: args.organizationId,
    purchaseId: purchase.id,
  });

  return {
    purchase: updated,
    alreadyRefunded: false,
    platformFeeReversed: split.platformFee,
    sellerReversed: split.payeeNet,
  };
}