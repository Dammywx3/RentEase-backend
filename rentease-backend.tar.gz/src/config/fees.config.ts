export type PaymentKind = "rent" | "buy" | "subscription";

export type FeeContext = {
  paymentKind: PaymentKind;
  amount: number;     // total paid amount
  currency: string;   // e.g. "USD" or "NGN"
};

export type FeeSplit = {
  platformFee: number; // >= 0
  payeeNet: number;    // >= 0
  pctUsed: number;
};

/**
 * SINGLE SOURCE OF TRUTH
 * Change these values in one place only.
 */
export const FEES = {
  platformFeePct: 2.5,
  minPlatformFee: 0,
  maxPlatformFee: Number.POSITIVE_INFINITY,
} as const;

export function round2(n: number): number {
  // Safe for numeric(15,2)
  return Math.round(n * 100) / 100;
}

export function computePlatformFeeSplit(ctx: FeeContext): FeeSplit {
  const pct = FEES.platformFeePct;

  let fee = round2((ctx.amount * pct) / 100);
  if (fee < FEES.minPlatformFee) fee = FEES.minPlatformFee;
  if (fee > FEES.maxPlatformFee) fee = FEES.maxPlatformFee;

  const net = round2(ctx.amount - fee);

  return {
    platformFee: fee,
    payeeNet: net,
    pctUsed: pct,
  };
}
