import { z } from "zod";

const EnvSchema = z.object({
  NODE_ENV: z.string().optional(),

  // Paystack
  PAYSTACK_SECRET_KEY: z.string().min(10, "PAYSTACK_SECRET_KEY is required"),
  PAYSTACK_PUBLIC_KEY: z.string().min(10).optional(),
  PAYSTACK_WEBHOOK_SECRET: z.string().min(10).optional(),
  PAYSTACK_BASE_URL: z.string().url().optional(), // default: https://api.paystack.co
  PAYSTACK_CALLBACK_URL: z.string().url().optional(),
});

type PaymentEnv = z.infer<typeof EnvSchema>;

function readEnv(): PaymentEnv {
  const parsed = EnvSchema.safeParse(process.env);
  if (!parsed.success) {
    const msg = parsed.error.issues
      .map((i) => `${i.path.join(".") || "env"}: ${i.message}`)
      .join("\n");
    throw new Error(`Invalid environment configuration:\n${msg}`);
  }
  return parsed.data;
}

const env = readEnv();

function isLiveKey(sk: string) {
  return sk.startsWith("sk_live_");
}
function isTestKey(sk: string) {
  return sk.startsWith("sk_test_");
}

export const paymentConfig = {
  provider: "paystack" as const,

  env: (env.NODE_ENV ?? "development") as string,
  isProduction: (env.NODE_ENV ?? "").toLowerCase() === "production",

  paystack: {
    baseUrl: env.PAYSTACK_BASE_URL ?? "https://api.paystack.co",
    secretKey: env.PAYSTACK_SECRET_KEY,
    publicKey: env.PAYSTACK_PUBLIC_KEY ?? null,

    // Signature verification:
    // Paystack uses your SECRET KEY to sign the raw request payload (HMAC SHA512)
    webhookSecret: env.PAYSTACK_WEBHOOK_SECRET ?? env.PAYSTACK_SECRET_KEY,

    callbackUrl: env.PAYSTACK_CALLBACK_URL ?? null,

    mode: isLiveKey(env.PAYSTACK_SECRET_KEY)
      ? ("live" as const)
      : isTestKey(env.PAYSTACK_SECRET_KEY)
      ? ("test" as const)
      : ("unknown" as const),
  },
} as const;

if (paymentConfig.paystack.mode === "unknown") {
  // eslint-disable-next-line no-console
  console.warn(
    "[payment.config] PAYSTACK_SECRET_KEY does not look like sk_test_* or sk_live_*. mode=unknown"
  );
}
