import { Pool, type PoolClient } from "pg";
import type { QueryResult, QueryResultRow } from "pg";
import { env } from "./env.js";

export const pool = new Pool({
  connectionString: env.databaseUrl,
  max: Number(process.env.DB_POOL_MAX ?? 10),
  idleTimeoutMillis: Number(process.env.DB_IDLE_TIMEOUT_MS ?? 30_000),
  statement_timeout: Number(process.env.DB_STATEMENT_TIMEOUT_MS ?? 15_000),
});

export function query<T extends QueryResultRow = any>(
  text: string,
  params: readonly any[] = []
): Promise<QueryResult<T>> {
  return pool.query<T>(text, params as any);
}

export async function withTransaction<T>(
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    try { await client.query("ROLLBACK"); } catch {}
    throw err;
  } finally {
    client.release();
  }
}

export type RlsContext = { userId: string; organizationId: string };

export async function withRlsTransaction<T>(
  ctx: RlsContext,
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  if (!ctx.userId) throw new Error("withRlsTransaction missing userId");
  if (!ctx.organizationId) throw new Error("withRlsTransaction missing organizationId");

  return withTransaction(async (client) => {
    // ✅ Force UTC for this transaction/connection
    await client.query("SET LOCAL TIME ZONE 'UTC'");

    await client.query("SELECT set_config('app.current_user', $1, true)", [String(ctx.userId)]);
    await client.query("SELECT set_config('app.current_organization', $1, true)", [String(ctx.organizationId)]);
    return fn(client);
  });
}

export async function closePool(): Promise<void> {
  await pool.end();
}