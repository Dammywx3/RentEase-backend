export type PlanId = "free" | "premium";
export type BillingCycle = "monthly" | "yearly";

export const PLANS = {
  free: {
    id: "free" as const,
    monthlyPriceNGN: 0,
    access: "limited",
  },
  premium: {
    id: "premium" as const,
    monthlyPriceNGN: 15000,
    yearlyDiscountPct: 10, // 10% off annual
    access: "full",
  },
} as const;

export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Returns how much user should pay for the plan.
 * - premium monthly: 15000 NGN
 * - premium yearly: 12 * 15000 minus 10%
 */
export function computePlanPriceNGN(planId: PlanId, cycle: BillingCycle): number {
  if (planId === "free") return 0;

  const monthly = PLANS.premium.monthlyPriceNGN;

  if (cycle === "monthly") return monthly;

  const yearBase = monthly * 12;
  const discount = (PLANS.premium.yearlyDiscountPct / 100) * yearBase;
  return round2(yearBase - discount);
}
