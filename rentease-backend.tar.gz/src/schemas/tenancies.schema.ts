import { z } from "zod";

export const tenancyStatusSchema = z.enum(["active", "ended", "terminated", "pending_start"]);

const dateOnly = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Expected YYYY-MM-DD");

/** --- CREATE TENANCY --- */
export const createTenancyBodySchema = z.object({
  tenantId: z.string().uuid(),
  propertyId: z.string().uuid(),
  listingId: z.string().uuid().nullable().optional(),

  rentAmount: z.number().positive(),
  securityDeposit: z.number().nonnegative().nullable().optional(),

  startDate: dateOnly,
  nextDueDate: dateOnly,

  paymentCycle: z.string().optional(),
  status: tenancyStatusSchema.optional(),

  terminationReason: z.string().max(5000).nullable().optional(),
});

export type CreateTenancyBody = z.infer<typeof createTenancyBodySchema>;

/** --- LIST TENANCIES --- */
export const listTenanciesQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(10),
  offset: z.coerce.number().int().min(0).default(0),

  tenantId: z.string().uuid().optional(),
  propertyId: z.string().uuid().optional(),
  listingId: z.string().uuid().optional(),
  status: tenancyStatusSchema.optional(),
});

export type ListTenanciesQuery = z.infer<typeof listTenanciesQuerySchema>;

/** --- END TENANCY --- */
export const endTenancyParamsSchema = z.object({
  id: z.string().uuid(),
});

export const endTenancyBodySchema = z.object({
  status: z.enum(["ended", "terminated"]).default("ended"),
  endDate: dateOnly.optional(), // if omitted server can default (repo/service can set)
  terminationReason: z.string().max(5000).nullable().optional(),
});

export type EndTenancyParams = z.infer<typeof endTenancyParamsSchema>;
export type EndTenancyBody = z.infer<typeof endTenancyBodySchema>;

/** --- START TENANCY (NEW) --- */
export const startTenancyParamsSchema = z.object({
  id: z.string().uuid(),
});

export const startTenancyBodySchema = z.object({
  startDate: dateOnly.optional(), // optional override; otherwise keep existing start_date
});

export type StartTenancyParams = z.infer<typeof startTenancyParamsSchema>;
export type StartTenancyBody = z.infer<typeof startTenancyBodySchema>;
