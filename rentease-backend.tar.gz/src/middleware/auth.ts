// src/middleware/auth.ts
import type { FastifyReply, FastifyRequest } from "fastify";

/**
 * Normalized user object we attach to req.user
 */
export type AuthUser = {
  userId: string;
  organizationId: string;
  role: "tenant" | "landlord" | "agent" | "admin";
  email?: string;
};

const ALLOWED_ROLES = new Set<AuthUser["role"]>(["tenant", "landlord", "agent", "admin"]);

/**
 * Raw JWT payload can vary depending on what you sign:
 * - Some code uses { sub, org, role }
 * - Some uses { userId, organizationId, role }
 */
type RawJwtPayload = Partial<{
  userId: string;
  organizationId: string;
  role: string; // keep raw as string; we validate into AuthUser["role"]
  email: string;

  // common JWT-style fields
  sub: string;
  org: string;

  iat: number;
  exp: number;
}>;

function getBearerToken(req: FastifyRequest): string | null {
  const header = req.headers.authorization;
  if (!header) return null;

  const [type, token] = header.trim().split(/\s+/);
  if (type?.toLowerCase() !== "bearer" || !token) return null;

  return token.trim();
}

function normalizeJwtPayload(raw: RawJwtPayload): AuthUser | null {
  const userId = (raw.userId ?? raw.sub ?? "").trim();
  const organizationId = (raw.organizationId ?? raw.org ?? "").trim();
  const roleRaw = (raw.role ?? "").trim();

  if (!userId || !organizationId || !roleRaw) return null;
  if (!ALLOWED_ROLES.has(roleRaw as AuthUser["role"])) return null;

  return {
    userId,
    organizationId,
    role: roleRaw as AuthUser["role"],
    email: raw.email ? String(raw.email) : undefined,
  };
}

function getOrgHeader(req: FastifyRequest): string {
  return String(req.headers["x-organization-id"] ?? "").trim();
}

/**
 * Enforce org rules and attach req.orgId.
 */
function enforceOrg(
  req: FastifyRequest,
  reply: FastifyReply,
  user: AuthUser,
  opts: { requireHeader: boolean }
): boolean {
  const headerOrg = getOrgHeader(req);

  // For protected routes: header MUST exist
  if (opts.requireHeader && !headerOrg) {
    reply.code(400).send({
      ok: false,
      error: "ORG_REQUIRED",
      message: "x-organization-id required",
    });
    return false;
  }

  // If header present, it MUST match token org (spoof protection)
  if (headerOrg && headerOrg !== user.organizationId) {
    reply.code(403).send({
      ok: false,
      error: "FORBIDDEN",
      message: "Token org does not match x-organization-id",
    });
    return false;
  }

  // Effective org
  (req as any).orgId = headerOrg || user.organizationId;
  return true;
}

/**
 * ✅ ADD THIS: Back-compat for older code (withRlsTransaction etc.)
 * Some helpers still look at req.rls.userId / req.auth.userId / req.user.sub.
 */
function attachCompatAuthFields(req: FastifyRequest, user: AuthUser) {
  const orgId = String((req as any).orgId ?? user.organizationId).trim();

  // Keep your normalized user
  (req as any).user = user;

  // Back-compat fields (safe to add even if unused)
  (req as any).rls = { userId: user.userId, organizationId: orgId };
  (req as any).auth = { userId: user.userId, sub: user.userId };

  // Some legacy code expects these on req.user
  (req as any).user.sub = user.userId;
  (req as any).user.org = orgId;
}

/**
 * Must be logged in (valid JWT).
 * ✅ Requires x-organization-id and enforces match with token org.
 * ✅ Attaches req.user and req.orgId.
 */
export async function requireAuth(req: FastifyRequest, reply: FastifyReply) {
  try {
    const raw = (await (req as any).jwtVerify()) as RawJwtPayload;

    const user = normalizeJwtPayload(raw);
    if (!user) {
      return reply.code(401).send({
        ok: false,
        error: "UNAUTHORIZED",
        message: "Invalid token payload",
      });
    }

    (req as any).user = user;

    if (!enforceOrg(req, reply, user, { requireHeader: true })) return;

    // ✅ ADD THIS (after org enforcement succeeds)
    attachCompatAuthFields(req, user);
  } catch {
    return reply.code(401).send({
      ok: false,
      error: "UNAUTHORIZED",
      message: "Invalid or missing token",
    });
  }
}

/**
 * If token exists, verify it and attach req.user + req.orgId.
 * ✅ If header org exists, it must match token org.
 * ✅ If header missing, fall back to token org (keeps it truly optional).
 */
export async function optionalAuth(req: FastifyRequest, reply: FastifyReply) {
  const token = getBearerToken(req);
  if (!token) return;

  try {
    const raw = (await (req as any).jwtVerify()) as RawJwtPayload;

    const user = normalizeJwtPayload(raw);
    if (!user) {
      return reply.code(401).send({
        ok: false,
        error: "UNAUTHORIZED",
        message: "Invalid token payload",
      });
    }

    (req as any).user = user;

    if (!enforceOrg(req, reply, user, { requireHeader: false })) return;

    // ✅ ADD THIS
    attachCompatAuthFields(req, user);
  } catch {
    return reply.code(401).send({
      ok: false,
      error: "UNAUTHORIZED",
      message: "Invalid token",
    });
  }
}

/**
 * Role guard factory.
 */
export function requireRole(...roles: AuthUser["role"][]) {
  return async function roleGuard(req: FastifyRequest, reply: FastifyReply) {
    const user = (req as any).user as AuthUser | undefined;

    if (!user) {
      return reply.code(401).send({
        ok: false,
        error: "UNAUTHORIZED",
        message: "Login required",
      });
    }

    if (!roles.includes(user.role)) {
      return reply.code(403).send({
        ok: false,
        error: "FORBIDDEN",
        message: "You do not have permission to access this resource",
      });
    }
  };
}

export const requireAdmin = [requireAuth, requireRole("admin")];