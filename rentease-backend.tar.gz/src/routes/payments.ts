import type { FastifyInstance } from "fastify";
import { z } from "zod";

import { createRentInvoicePaymentIntent, finalizePaystackSuccessForRentInvoice, verifyPaystackSignature } from "../services/rent_invoice_payments.service.js";

export async function paymentsRoutes(app: FastifyInstance) {
  // -------------------------------
  // Create rent-invoice payment intent (AUTH)
  // POST /rent-invoices/:id/payments/intent
  // -------------------------------
  app.post(
    "/rent-invoices/:id/payments/intent",
    { preHandler: [app.authenticate] },
    async (req, reply) => {
      const params = z.object({ id: z.string().uuid() }).parse((req as any).params);
      const body = z
        .object({
          paymentMethod: z.string().default("card"),
          amount: z.number().optional().nullable(), // partial allowed
          currency: z.string().optional().nullable(),
        })
        .default({ paymentMethod: "card" })
        .parse((req as any).body ?? { paymentMethod: "card" });

      const organizationId = String((req as any).orgId ?? "").trim();
      const userId = String((req as any).user?.userId ?? "").trim();

      if (!organizationId) {
        return reply.code(400).send({ ok: false, error: "ORG_REQUIRED", message: "Missing orgId from auth middleware" });
      }
      if (!userId) {
        return reply.code(401).send({ ok: false, error: "UNAUTHORIZED", message: "Missing authenticated user" });
      }

      const pgAny: any = (app as any).pg;
      if (!pgAny?.connect) {
        return reply.code(500).send({ ok: false, error: "PG_NOT_CONFIGURED", message: "Fastify pg plugin not found at app.pg" });
      }

      const client = await pgAny.connect();
      try {
        await client.query("BEGIN");

        // Important: set RLS context (use your existing keys that DB expects)
        await client.query("select set_config('app.organization_id', $1, true)", [organizationId]);
        await client.query("select set_config('request.header.x_organization_id', $1, true)", [organizationId]);
        await client.query("select set_config('request.jwt.claim.sub', $1, true)", [userId]);
        await client.query("select set_config('app.user_id', $1, true)", [userId]);

        const intent = await createRentInvoicePaymentIntent(client, {
          organizationId,
          invoiceId: params.id,
          paymentMethod: body.paymentMethod,
          amount: body.amount ?? null,
          currency: body.currency ?? null,
        });

        await client.query("COMMIT");
        return reply.send({ ok: true, data: intent });
      } catch (err: any) {
        try { await client.query("ROLLBACK"); } catch {}
        return reply.code(400).send({
          ok: false,
          error: err?.code ?? "BAD_REQUEST",
          message: err?.message ?? String(err),
        });
      } finally {
        client.release();
      }
    }
  );

  // -------------------------------
  // Paystack webhook (PUBLIC)
  // POST /webhooks/paystack
  //
  // NOTE:
  // For best verification, install @fastify/raw-body so we can access raw body.
  // If PAYSTACK_SECRET_KEY is set and raw body isn't available, we return 500 (fail safe).
  // -------------------------------

}
