import type { FastifyInstance } from "fastify";
import crypto from "node:crypto";
import { paymentConfig } from "../config/payment.config.js";
import { finalizePaystackChargeSuccess } from "../services/paystack_finalize.service.js";

export async function webhooksRoutes(app: FastifyInstance) {
  app.post(
    "/webhooks/paystack",
    {
      // fastify-raw-body reads this and attaches request.rawBody
      config: { rawBody: true },
    },
    async (request, reply) => {
      const secret = paymentConfig.paystack.webhookSecret;
      const signature = String((request.headers["x-paystack-signature"] ?? "")).trim();

      if (!signature) {
        return reply.code(400).send({ ok: false, error: "SIGNATURE_MISSING" });
      }

      const raw = (request as any).rawBody as Buffer | undefined;
      if (!raw || !Buffer.isBuffer(raw)) {
        return reply.code(500).send({ ok: false, error: "RAW_BODY_MISSING" });
      }

      const hash = crypto.createHmac("sha512", secret).update(raw).digest("hex");
      if (hash !== signature) {
        return reply.code(401).send({ ok: false, error: "INVALID_SIGNATURE" });
      }

      let event: any;
      try {
        event = JSON.parse(raw.toString("utf8"));
      } catch {
        return reply.code(400).send({ ok: false, error: "INVALID_JSON" });
      }

      // ✅ Verified event
      app.log.info({ event: event?.event, dataRef: event?.data?.reference }, "paystack webhook received");

      // Finalize in DB transaction (create splits -> set payments.successful -> trigger credits)
      // @ts-ignore - fastify-postgres decorates app.pg
      const pg = await app.pg.connect();
      try {
        await pg.query("BEGIN");
        const res = await finalizePaystackChargeSuccess(pg, event);
        if (!res.ok) {
          app.log.warn({ error: res.error, message: res.message }, "paystack finalize skipped/failed");
        }
        await pg.query("COMMIT");
      } catch (e) {
        try { await pg.query("ROLLBACK"); } catch {}
        app.log.error(e, "paystack finalize failed");
        // still return 200 to avoid repeated Paystack retries storm
      } finally {
        pg.release();
      }

      return reply.send({ ok: true });
    }
  );
}
