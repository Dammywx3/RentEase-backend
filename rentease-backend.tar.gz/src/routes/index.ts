import type { FastifyInstance } from "fastify";
import { webhooksRoutes } from "./webhooks.js";

import { healthRoutes } from "./health.js";
import { demoRoutes } from "./demo.js";

import { authRoutes } from "./auth.js";
import { meRoutes } from "./me.js";
import { organizationRoutes } from "./organizations.js";

import { propertyRoutes } from "./properties.js";
import { listingRoutes } from "./listings.js";
import { viewingRoutes } from "./viewings.js";
import { applicationRoutes } from "./applications.js";
import { tenancyRoutes } from "./tenancies.js";

import { rentInvoicesRoutes } from "./rent_invoices.js";
import purchasesRoutes from "./purchases.routes.js";
import { paymentsRoutes } from "./payments.js";

export async function registerRoutes(app: FastifyInstance) {
  await app.register(webhooksRoutes);

// Public / non-versioned routes
  await app.register(healthRoutes);
  await app.register(demoRoutes);

  // Versioned API routes
  await app.register(
    async (v1) => {
      await v1.register(authRoutes);
      await v1.register(meRoutes);

      await v1.register(organizationRoutes);
      await v1.register(propertyRoutes);
      await v1.register(listingRoutes);
      await v1.register(viewingRoutes);
      await v1.register(applicationRoutes);
      await v1.register(tenancyRoutes);

      await v1.register(rentInvoicesRoutes);
      await v1.register(purchasesRoutes);
    },
    { prefix: "/v1" }
  );
  await paymentsRoutes(app);
}
