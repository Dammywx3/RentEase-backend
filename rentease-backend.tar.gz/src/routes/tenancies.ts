// src/routes/tenancies.ts
import type { FastifyInstance, FastifyReply } from "fastify";

import { withRlsTransaction } from "../db.js";
import {
  createTenancyBodySchema,
  listTenanciesQuerySchema,
  endTenancyParamsSchema,
  endTenancyBodySchema,
  startTenancyParamsSchema,
  startTenancyBodySchema,
  type CreateTenancyBody,
  type ListTenanciesQuery,
  type EndTenancyBody,
  type EndTenancyParams,
  type StartTenancyBody,
  type StartTenancyParams,
} from "../schemas/tenancies.schema.js";
import { createTenancy, endTenancy, getTenancies, startTenancy } from "../services/tenancies.service.js";

function getRlsCtx(req: any): { userId: string; organizationId: string } {
  const userId = String(req?.user?.userId ?? "").trim();
  const organizationId = String(req?.orgId ?? "").trim();

  if (!userId) {
    const err: any = new Error("Missing authenticated user");
    err.code = "USER_ID_MISSING";
    throw err;
  }

  if (!organizationId) {
    const err: any = new Error("x-organization-id required");
    err.code = "ORG_REQUIRED";
    throw err;
  }

  return { userId, organizationId };
}

function handleCtxErrors(e: any, reply: FastifyReply) {
  if (e?.code === "ORG_REQUIRED") {
    return reply.code(400).send({ ok: false, error: "ORG_REQUIRED", message: "x-organization-id required" });
  }
  if (e?.code === "USER_ID_MISSING") {
    return reply.code(401).send({ ok: false, error: "UNAUTHORIZED", message: "Missing authenticated user" });
  }
  return null;
}

export async function tenancyRoutes(app: FastifyInstance) {
  app.get<{ Querystring: ListTenanciesQuery }>(
    "/tenancies",
    { preHandler: [app.authenticate] },
    async (req, reply) => {
      try {
        const q = listTenanciesQuerySchema.parse(req.query ?? {});
        const ctx = getRlsCtx(req);

        const data = await withRlsTransaction(ctx, (client) =>
          getTenancies(client, {
            limit: q.limit,
            offset: q.offset,
            tenantId: q.tenantId,
            propertyId: q.propertyId,
            listingId: q.listingId,
            status: q.status as any,
          })
        );

        return { ok: true, data, paging: { limit: q.limit, offset: q.offset } };
      } catch (e: any) {
        const handled = handleCtxErrors(e, reply);
        if (handled) return handled;
        throw e;
      }
    }
  );

  app.post<{ Body: CreateTenancyBody }>(
    "/tenancies",
    { preHandler: [app.authenticate] },
    async (req, reply) => {
      try {
        const body = createTenancyBodySchema.parse(req.body ?? {});
        const ctx = getRlsCtx(req);

        const result = await withRlsTransaction(ctx, (client) =>
          createTenancy(client, {
            tenantId: body.tenantId,
            propertyId: body.propertyId,
            listingId: body.listingId ?? null,
            rentAmount: body.rentAmount,
            securityDeposit: body.securityDeposit ?? null,
            startDate: body.startDate,
            nextDueDate: body.nextDueDate,
            paymentCycle: (body.paymentCycle as any) ?? null,
            status: (body.status as any) ?? null,
            terminationReason: body.terminationReason ?? null,
          })
        );

        return { ok: true, data: result.row, reused: result.reused, patched: result.patched };
      } catch (e: any) {
        const handled = handleCtxErrors(e, reply);
        if (handled) return handled;
        throw e;
      }
    }
  );

  app.patch<{ Params: EndTenancyParams; Body: EndTenancyBody }>(
    "/tenancies/:id/end",
    { preHandler: [app.authenticate] },
    async (req, reply) => {
      try {
        const params = endTenancyParamsSchema.parse(req.params ?? {});
        const body = endTenancyBodySchema.parse(req.body ?? {});
        const ctx = getRlsCtx(req);

        const result = await withRlsTransaction(ctx, (client) =>
          endTenancy(client, {
            id: params.id,
            status: body.status,
            endDate: body.endDate ?? null,
            terminationReason: body.terminationReason ?? null,
          })
        );

        return { ok: true, data: result.row, changed: result.changed };
      } catch (e: any) {
        const handled = handleCtxErrors(e, reply);
        if (handled) return handled;
        throw e;
      }
    }
  );

  app.patch<{ Params: StartTenancyParams; Body: StartTenancyBody }>(
    "/tenancies/:id/start",
    { preHandler: [app.authenticate] },
    async (req, reply) => {
      try {
        const params = startTenancyParamsSchema.parse(req.params ?? {});
        const body = startTenancyBodySchema.parse(req.body ?? {});
        const ctx = getRlsCtx(req);

        const result = await withRlsTransaction(ctx, (client) =>
          startTenancy(client, {
            id: params.id,
            startDate: body.startDate ?? null,
          })
        );

        return { ok: true, data: result.row, changed: result.changed };
      } catch (e: any) {
        const handled = handleCtxErrors(e, reply);
        if (handled) return handled;
        throw e;
      }
    }
  );
}