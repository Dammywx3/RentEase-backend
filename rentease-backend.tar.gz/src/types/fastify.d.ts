// src/types/fastify.d.ts
import "fastify";
import "@fastify/jwt";

import type { FastifyReply, FastifyRequest } from "fastify";
import type { AuthUser } from "../middleware/auth.js";
import type { JwtPayload } from "../plugins/jwt.js";

declare module "@fastify/jwt" {
  interface FastifyJWT {
    payload: JwtPayload;
    user: JwtPayload; // what req.jwtVerify() sets internally
  }
}

declare module "fastify" {
  interface FastifyInstance {
    /**
     * Decorated by src/plugins/jwt.ts
     * These enforce org header + token validity (via requireAuth/optionalAuth)
     */
    authenticate: (req: FastifyRequest, reply: FastifyReply) => Promise<void>;
    optionalAuthenticate: (req: FastifyRequest, reply: FastifyReply) => Promise<void>;
  }

  interface FastifyRequest {
    /**
     * Normalized identity set by your middleware/auth.ts (requireAuth/optionalAuth)
     */
    user?: AuthUser;

    /**
     * Effective org ID set by middleware/auth.ts
     * Routes should trust ONLY this (not headers directly).
     */
    orgId?: string;

    /**
     * Legacy/optional fields (keep only if still used elsewhere)
     */
    rls?: {
      userId?: string;
      organizationId?: string;
    };

    auth?: {
      userId?: string;
      sub?: string;
    };
  }
}

export {};